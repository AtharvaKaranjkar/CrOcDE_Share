<?php
/**
 * admin/audit_log.php — Full audit log viewer with filters + pagination.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

$action_filter = trim($_GET['action'] ?? '');
$actor_filter  = trim($_GET['actor']  ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 50;
$offset = ($page - 1) * $per_page;

$conditions = [];
$params = [];
$types = '';

if ($action_filter !== '') {
    $conditions[] = "al.action = ?";
    $params[] = $action_filter; $types .= 's';
}
if ($actor_filter !== '') {
    $conditions[] = "u.username = ?";
    $params[] = $actor_filter; $types .= 's';
}
$where = empty($conditions) ? '1=1' : implode(' AND ', $conditions);

// Count
$count_sql = "SELECT COUNT(*) AS n FROM audit_log al LEFT JOIN users u ON u.user_id = al.actor_id WHERE {$where}";
$stmt = $conn->prepare($count_sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = (int)$stmt->get_result()->fetch_assoc()['n'];
$total_pages = max(1, (int)ceil($total / $per_page));

// Fetch
$list_sql = "
    SELECT al.log_id, al.action, al.target_type, al.target_id, al.details, al.created_at,
           u.username AS actor_name
    FROM audit_log al
    LEFT JOIN users u ON u.user_id = al.actor_id
    WHERE {$where}
    ORDER BY al.log_id DESC
    LIMIT {$per_page} OFFSET {$offset}
";
$stmt = $conn->prepare($list_sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Distinct action list for the dropdown
$actions = $conn->query("SELECT DISTINCT action FROM audit_log ORDER BY action")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Audit log · Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="flex-between mb-2">
  <h1 class="mt-0 mb-0">Audit log</h1>
  <a class="btn btn-outline" href="<?= BASE_URL ?>/admin/index.php">← Admin home</a>
</div>

<div class="card">
  <form method="get" action="<?= BASE_URL ?>/admin/audit_log.php"
        style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div class="form-group" style="margin-bottom:0;min-width:200px">
      <label for="action">Action</label>
      <select id="action" name="action">
        <option value="">All actions</option>
        <?php foreach ($actions as $a): ?>
          <option value="<?= h($a['action']) ?>" <?= $action_filter === $a['action'] ? 'selected' : '' ?>>
            <?= h($a['action']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group" style="margin-bottom:0;min-width:200px">
      <label for="actor">Actor username</label>
      <input id="actor" name="actor" type="text" maxlength="50" value="<?= h($actor_filter) ?>" placeholder="e.g. alice">
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-primary" type="submit">Filter</button>
      <?php if ($action_filter !== '' || $actor_filter !== ''): ?>
        <a class="btn btn-outline" href="<?= BASE_URL ?>/admin/audit_log.php">Clear</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="card">
  <h2 class="card-title">
    <?= $total ?> entries
    <?php if ($action_filter !== '' || $actor_filter !== ''): ?>
      <span class="text-muted" style="font-weight:400">(filtered)</span>
    <?php endif; ?>
  </h2>

  <?php if (empty($rows)): ?>
    <p class="text-muted mb-0">No entries match.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>When</th>
          <th>Actor</th>
          <th>Action</th>
          <th>Target</th>
          <th>Details</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= (int)$r['log_id'] ?></td>
            <td class="text-muted" style="font-size:12px">
              <?= h(date('M j, Y g:i:s A', strtotime($r['created_at']))) ?>
            </td>
            <td>
              <?php if ($r['actor_name']): ?>
                <a href="<?= BASE_URL ?>/profile.php?user=<?= h($r['actor_name']) ?>">
                  @<?= h($r['actor_name']) ?>
                </a>
              <?php else: ?>
                <em class="text-muted">system / deleted</em>
              <?php endif; ?>
            </td>
            <td><span class="badge"><?= h($r['action']) ?></span></td>
            <td class="text-muted" style="font-size:12px">
              <?php if ($r['target_type']): ?>
                <?= h($r['target_type']) ?><?= $r['target_id'] ? '#' . (int)$r['target_id'] : '' ?>
              <?php endif; ?>
            </td>
            <td style="font-size:13px"><?= h($r['details']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php if ($total_pages > 1): ?>
<div class="flex gap-2 mt-2" style="justify-content:center">
  <?php
  $qs_base = 'action=' . urlencode($action_filter) . '&actor=' . urlencode($actor_filter);
  ?>
  <?php if ($page > 1): ?>
    <a class="btn btn-outline btn-sm" href="?<?= $qs_base ?>&page=<?= $page - 1 ?>">← Previous</a>
  <?php endif; ?>
  <span class="text-muted" style="align-self:center">page <?= $page ?> of <?= $total_pages ?></span>
  <?php if ($page < $total_pages): ?>
    <a class="btn btn-outline btn-sm" href="?<?= $qs_base ?>&page=<?= $page + 1 ?>">Next →</a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>