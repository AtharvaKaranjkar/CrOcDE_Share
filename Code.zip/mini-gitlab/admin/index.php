<?php
/**
 * admin/index.php — Admin dashboard.
 *
 * Shows site-wide stats and quick links into the admin sub-pages.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

// Site-wide stats with a single multi-subquery SELECT
$stats = $conn->query("
    SELECT
      (SELECT COUNT(*) FROM users WHERE role='user' AND is_suspended=0) AS active_users,
      (SELECT COUNT(*) FROM users WHERE role='user' AND is_suspended=1) AS suspended_users,
      (SELECT COUNT(*) FROM repositories WHERE deleted_at IS NULL) AS active_repos,
      (SELECT COUNT(*) FROM repositories WHERE deleted_at IS NOT NULL) AS deleted_repos,
      (SELECT COUNT(*) FROM repositories WHERE visibility='private' AND deleted_at IS NULL) AS private_repos,
      (SELECT COUNT(*) FROM versions) AS total_versions,
      (SELECT COUNT(*) FROM change_requests WHERE status='pending') AS pending_requests,
      (SELECT COUNT(*) FROM comments WHERE deleted_at IS NULL) AS comments,
      (SELECT COUNT(*) FROM audit_log) AS audit_rows
")->fetch_assoc();

// Top 5 most-followed users (window function or simple ORDER BY)
$top_users = $conn->query("
    SELECT u.username,
           (SELECT COUNT(*) FROM follows WHERE followee_id = u.user_id) AS follower_count,
           (SELECT COUNT(*) FROM repositories WHERE owner_id = u.user_id AND deleted_at IS NULL) AS repo_count
    FROM users u
    WHERE u.role = 'user'
    ORDER BY follower_count DESC, repo_count DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

// Latest 5 audit entries
$recent_audit = $conn->query("
    SELECT al.log_id, al.action, al.target_type, al.target_id, al.details, al.created_at,
           u.username AS actor_name
    FROM audit_log al
    LEFT JOIN users u ON u.user_id = al.actor_id
    ORDER BY al.log_id DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">Admin Panel</h1>
<p class="text-muted">
  Logged in as <strong>@<?= h(current_username()) ?></strong>
  <span class="badge badge-admin">admin</span>
</p>

<!-- Stats grid -->
<div class="card">
  <h2 class="card-title">Site stats</h2>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px">
    <?php
    $cards = [
      'Active users'      => $stats['active_users'],
      'Suspended'         => $stats['suspended_users'],
      'Active repos'      => $stats['active_repos'],
      'Deleted repos'     => $stats['deleted_repos'],
      'Private repos'     => $stats['private_repos'],
      'Versions'          => $stats['total_versions'],
      'Pending requests'  => $stats['pending_requests'],
      'Comments'          => $stats['comments'],
      'Audit rows'        => $stats['audit_rows'],
    ];
    foreach ($cards as $label => $val): ?>
      <div style="background:var(--grey-100);padding:14px 16px;border-radius:6px">
        <div style="font-size:24px;font-weight:700;color:var(--crimson)"><?= (int)$val ?></div>
        <div style="font-size:12px;color:var(--grey-700)"><?= h($label) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Quick links -->
<div class="card">
  <h2 class="card-title">Manage</h2>
  <div class="flex gap-2" style="flex-wrap:wrap">
    <a class="btn btn-primary" href="<?= BASE_URL ?>/admin/users.php">Users</a>
    <a class="btn btn-primary" href="<?= BASE_URL ?>/admin/repos.php">Repositories</a>
    <a class="btn btn-primary" href="<?= BASE_URL ?>/admin/audit_log.php">Audit log</a>
    <a class="btn btn-danger"  href="<?= BASE_URL ?>/admin/reset.php">Reset database</a>
  </div>
</div>

<!-- Top users -->
<div class="card">
  <h2 class="card-title">Top users by followers</h2>
  <?php if (empty($top_users)): ?>
    <p class="text-muted mb-0">No users yet.</p>
  <?php else: ?>
    <table class="table">
      <thead><tr><th>Username</th><th>Followers</th><th>Repos</th></tr></thead>
      <tbody>
        <?php foreach ($top_users as $u): ?>
          <tr>
            <td><a href="<?= BASE_URL ?>/profile.php?user=<?= h($u['username']) ?>">@<?= h($u['username']) ?></a></td>
            <td><?= (int)$u['follower_count'] ?></td>
            <td><?= (int)$u['repo_count'] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<!-- Recent audit -->
<div class="card">
  <h2 class="card-title">Recent audit log</h2>
  <table class="table">
    <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Details</th></tr></thead>
    <tbody>
      <?php foreach ($recent_audit as $a): ?>
        <tr>
          <td class="text-muted" style="font-size:12px">
            <?= h(date('M j, g:i A', strtotime($a['created_at']))) ?>
          </td>
          <td><?= $a['actor_name'] ? '@' . h($a['actor_name']) : '<em>system</em>' ?></td>
          <td><span class="badge"><?= h($a['action']) ?></span></td>
          <td style="font-size:13px;color:var(--grey-700)"><?= h($a['details']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <p class="text-muted mt-2 mb-0">
    <a href="<?= BASE_URL ?>/admin/audit_log.php">View full audit log →</a>
  </p>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>