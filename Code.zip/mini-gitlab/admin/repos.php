<?php
/**
 * admin/repos.php — All repositories (incl. private and soft-deleted).
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

$filter = $_GET['filter'] ?? 'all';   // all | public | private | deleted
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 25;
$offset = ($page - 1) * $per_page;

$where = "1=1";
if ($filter === 'public')  $where = "visibility = 'public' AND deleted_at IS NULL";
if ($filter === 'private') $where = "visibility = 'private' AND deleted_at IS NULL";
if ($filter === 'deleted') $where = "deleted_at IS NOT NULL";

$total = (int)$conn->query("SELECT COUNT(*) AS n FROM repositories WHERE {$where}")
                 ->fetch_assoc()['n'];
$total_pages = max(1, (int)ceil($total / $per_page));

$repos = $conn->query("
    SELECT r.repo_id, r.name, r.language, r.visibility, r.view_count,
           r.created_at, r.deleted_at,
           u.username AS owner_username,
           (SELECT COUNT(*) FROM versions WHERE repo_id = r.repo_id) AS total_versions,
           (SELECT COUNT(*) FROM comments WHERE repo_id = r.repo_id AND deleted_at IS NULL) AS comment_count,
           (SELECT COUNT(*) FROM change_requests WHERE repo_id = r.repo_id AND status='pending') AS pending_cr
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE {$where}
    ORDER BY r.repo_id DESC
    LIMIT {$per_page} OFFSET {$offset}
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Repositories · Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="flex-between mb-2">
  <h1 class="mt-0 mb-0">All repositories</h1>
  <a class="btn btn-outline" href="<?= BASE_URL ?>/admin/index.php">← Admin home</a>
</div>

<div class="card">
  <div class="flex gap-2 mb-2" style="flex-wrap:wrap">
    <a class="btn btn-sm <?= $filter==='all'     ? 'btn-primary' : 'btn-outline' ?>" href="?filter=all">All (<?= $total ?>)</a>
    <a class="btn btn-sm <?= $filter==='public'  ? 'btn-primary' : 'btn-outline' ?>" href="?filter=public">Public</a>
    <a class="btn btn-sm <?= $filter==='private' ? 'btn-primary' : 'btn-outline' ?>" href="?filter=private">Private</a>
    <a class="btn btn-sm <?= $filter==='deleted' ? 'btn-primary' : 'btn-outline' ?>" href="?filter=deleted">Soft-deleted</a>
  </div>

  <?php if (empty($repos)): ?>
    <p class="text-muted mb-0">No repositories match this filter.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Owner</th>
          <th>Language</th>
          <th>Visibility</th>
          <th>v</th>
          <th>💬</th>
          <th>⏳</th>
          <th>👁</th>
          <th>Created</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($repos as $r): ?>
          <tr>
            <td><?= (int)$r['repo_id'] ?></td>
            <td>
              <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$r['repo_id'] ?>">
                <?= h($r['name']) ?>
              </a>
              <?php if ($r['deleted_at']): ?>
                <span class="badge" style="background:#fdecea;color:#c62828;font-size:10px">deleted</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?= BASE_URL ?>/profile.php?user=<?= h($r['owner_username']) ?>">
                @<?= h($r['owner_username']) ?>
              </a>
            </td>
            <td><span class="badge badge-crimson"><?= h($r['language']) ?></span></td>
            <td>
              <span class="badge <?= $r['visibility'] === 'public' ? 'badge-public' : 'badge-private' ?>">
                <?= h($r['visibility']) ?>
              </span>
            </td>
            <td><?= (int)$r['total_versions'] ?></td>
            <td><?= (int)$r['comment_count'] ?></td>
            <td>
              <?php if ($r['pending_cr'] > 0): ?>
                <span class="badge" style="background:#fff8e1;color:#7c5c00"><?= (int)$r['pending_cr'] ?></span>
              <?php else: ?>
                <?= (int)$r['pending_cr'] ?>
              <?php endif; ?>
            </td>
            <td><?= (int)$r['view_count'] ?></td>
            <td class="text-muted" style="font-size:12px">
              <?= h(date('M j, Y', strtotime($r['created_at']))) ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p class="text-muted mt-2 mb-0" style="font-size:12px">
      Columns: v = versions · 💬 = comments · ⏳ = pending change requests · 👁 = views
    </p>
  <?php endif; ?>
</div>

<?php if ($total_pages > 1): ?>
<div class="flex gap-2 mt-2" style="justify-content:center">
  <?php if ($page > 1): ?>
    <a class="btn btn-outline btn-sm" href="?filter=<?= h($filter) ?>&page=<?= $page - 1 ?>">← Previous</a>
  <?php endif; ?>
  <span class="text-muted" style="align-self:center">page <?= $page ?> of <?= $total_pages ?></span>
  <?php if ($page < $total_pages): ?>
    <a class="btn btn-outline btn-sm" href="?filter=<?= h($filter) ?>&page=<?= $page + 1 ?>">Next →</a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>