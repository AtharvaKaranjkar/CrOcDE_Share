<?php
/**
 * admin/reset.php — Wipe non-admin data via sp_reset_database.
 *
 * Two-step confirmation: GET shows a warning page, POST executes.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

$me = current_user_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $confirm = trim($_POST['confirm'] ?? '');
    if ($confirm !== 'RESET') {
        flash('error', "You must type RESET (in uppercase) to confirm.");
        redirect('/admin/reset.php');
    }

    try {
        $stmt = $conn->prepare("CALL sp_reset_database(?)");
        $stmt->bind_param('i', $me);
        $stmt->execute();
        flash('success', 'Database reset complete. Only the admin user and default tags remain.');
        redirect('/admin/index.php');
    } catch (mysqli_sql_exception $e) {
        flash('error', 'Reset failed: ' . $e->getMessage());
        redirect('/admin/reset.php');
    }
}

// Show current counts before reset
$stats = $conn->query("
    SELECT
      (SELECT COUNT(*) FROM users WHERE role='user') AS users,
      (SELECT COUNT(*) FROM repositories) AS repos,
      (SELECT COUNT(*) FROM versions) AS versions,
      (SELECT COUNT(*) FROM comments) AS comments,
      (SELECT COUNT(*) FROM change_requests) AS change_requests,
      (SELECT COUNT(*) FROM reactions) AS reactions,
      (SELECT COUNT(*) FROM forks) AS forks,
      (SELECT COUNT(*) FROM follows) AS follows,
      (SELECT COUNT(*) FROM notifications) AS notifications,
      (SELECT COUNT(*) FROM audit_log) AS audit_log
")->fetch_assoc();

$page_title = 'Reset database · Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="flex-between mb-2">
  <h1 class="mt-0 mb-0" style="color:var(--error)">Reset database</h1>
  <a class="btn btn-outline" href="<?= BASE_URL ?>/admin/index.php">← Admin home</a>
</div>

<div class="card">
  <h2 class="card-title" style="color:var(--error)">⚠ This will erase the following data permanently</h2>

  <table class="table" style="max-width:400px">
    <tbody>
      <tr><td>Non-admin users</td><td><strong><?= (int)$stats['users'] ?></strong></td></tr>
      <tr><td>Repositories</td><td><strong><?= (int)$stats['repos'] ?></strong></td></tr>
      <tr><td>Versions</td><td><strong><?= (int)$stats['versions'] ?></strong></td></tr>
      <tr><td>Comments</td><td><strong><?= (int)$stats['comments'] ?></strong></td></tr>
      <tr><td>Change requests</td><td><strong><?= (int)$stats['change_requests'] ?></strong></td></tr>
      <tr><td>Reactions</td><td><strong><?= (int)$stats['reactions'] ?></strong></td></tr>
      <tr><td>Forks</td><td><strong><?= (int)$stats['forks'] ?></strong></td></tr>
      <tr><td>Follows</td><td><strong><?= (int)$stats['follows'] ?></strong></td></tr>
      <tr><td>Notifications</td><td><strong><?= (int)$stats['notifications'] ?></strong></td></tr>
      <tr><td>Audit log rows</td><td><strong><?= (int)$stats['audit_log'] ?></strong></td></tr>
    </tbody>
  </table>

  <p class="text-muted">
    The admin account stays. Default tags are re-seeded.
    AUTO_INCREMENT counters reset so the next new user becomes <code>user_id=2</code>.
  </p>
</div>

<div class="card">
  <h2 class="card-title">Confirm reset</h2>
  <p>Type <strong>RESET</strong> in the box below (uppercase) to confirm.</p>
  <form method="post" action="<?= BASE_URL ?>/admin/reset.php">
    <div class="form-group">
      <input type="text" name="confirm" required autocomplete="off"
             placeholder="Type RESET to confirm" style="max-width:300px">
    </div>
    <button class="btn btn-danger" type="submit">Reset database now</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>