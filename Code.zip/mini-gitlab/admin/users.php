<?php
/**
 * admin/users.php — List all users with suspend/unsuspend toggles.
 *
 * Admin row is shown but its suspend button is disabled (the CHECK
 * constraint would reject it anyway).
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

$me = current_user_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $target_id = (int)($_POST['user_id'] ?? 0);

    if ($action === 'toggle_suspend' && $target_id > 0) {
        // Look up the user
        $stmt = $conn->prepare("SELECT username, role, is_suspended FROM users WHERE user_id = ?");
        $stmt->bind_param('i', $target_id);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();

        if (!$u) {
            flash('error', 'User not found.');
        } elseif ($u['role'] === 'admin') {
            flash('error', "You can't suspend an admin.");
        } else {
            $new_state = $u['is_suspended'] ? 0 : 1;
            $stmt = $conn->prepare("UPDATE users SET is_suspended = ? WHERE user_id = ?");
            $stmt->bind_param('ii', $new_state, $target_id);
            $stmt->execute();

            $action_name = $new_state ? 'user_suspended' : 'user_unsuspended';
            audit_log($conn, $me, $action_name, 'users', $target_id,
                      "@{$u['username']} " . ($new_state ? 'suspended' : 'unsuspended') . '.');

            // Notify the user
            $nt = $new_state ? 'account_suspended' : 'account_unsuspended';
            $msg = $new_state
                ? "Your account has been suspended by an administrator."
                : "Your account has been reactivated.";
            $stmt2 = $conn->prepare("
                INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)
            ");
            $stmt2->bind_param('iss', $target_id, $nt, $msg);
            $stmt2->execute();

            flash('success', "@{$u['username']} " . ($new_state ? 'suspended' : 'unsuspended') . '.');
        }
        redirect('/admin/users.php');
    }
}

// Filter & pagination
$filter = $_GET['filter'] ?? 'all';   // all | active | suspended | admin
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 25;
$offset = ($page - 1) * $per_page;

$where = "1=1";
if ($filter === 'active')    $where = "role = 'user' AND is_suspended = 0";
if ($filter === 'suspended') $where = "role = 'user' AND is_suspended = 1";
if ($filter === 'admin')     $where = "role = 'admin'";

$total = (int)$conn->query("SELECT COUNT(*) AS n FROM users WHERE {$where}")
                 ->fetch_assoc()['n'];
$total_pages = max(1, (int)ceil($total / $per_page));

$users = $conn->query("
    SELECT u.user_id, u.username, u.email, u.role, u.is_suspended, u.created_at,
           (SELECT COUNT(*) FROM repositories WHERE owner_id = u.user_id AND deleted_at IS NULL) AS repo_count
    FROM users u
    WHERE {$where}
    ORDER BY u.user_id ASC
    LIMIT {$per_page} OFFSET {$offset}
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Users · Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="flex-between mb-2">
  <h1 class="mt-0 mb-0">Users</h1>
  <a class="btn btn-outline" href="<?= BASE_URL ?>/admin/index.php">← Admin home</a>
</div>

<div class="card">
  <div class="flex gap-2 mb-2" style="flex-wrap:wrap">
    <a class="btn btn-sm <?= $filter==='all'       ? 'btn-primary' : 'btn-outline' ?>" href="?filter=all">All (<?= $total ?>)</a>
    <a class="btn btn-sm <?= $filter==='active'    ? 'btn-primary' : 'btn-outline' ?>" href="?filter=active">Active</a>
    <a class="btn btn-sm <?= $filter==='suspended' ? 'btn-primary' : 'btn-outline' ?>" href="?filter=suspended">Suspended</a>
    <a class="btn btn-sm <?= $filter==='admin'     ? 'btn-primary' : 'btn-outline' ?>" href="?filter=admin">Admin</a>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th>Status</th>
        <th>Repos</th>
        <th>Joined</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= (int)$u['user_id'] ?></td>
          <td>
            <a href="<?= BASE_URL ?>/profile.php?user=<?= h($u['username']) ?>">
              @<?= h($u['username']) ?>
            </a>
          </td>
          <td class="text-muted" style="font-size:13px"><?= h($u['email']) ?></td>
          <td>
            <?php if ($u['role'] === 'admin'): ?>
              <span class="badge badge-admin">admin</span>
            <?php else: ?>
              <span class="badge">user</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($u['is_suspended']): ?>
              <span class="badge" style="background:#fdecea;color:#c62828">suspended</span>
            <?php else: ?>
              <span class="badge badge-public">active</span>
            <?php endif; ?>
          </td>
          <td><?= (int)$u['repo_count'] ?></td>
          <td class="text-muted" style="font-size:13px">
            <?= h(date('M j, Y', strtotime($u['created_at']))) ?>
          </td>
          <td>
            <?php if ($u['role'] === 'admin'): ?>
              <em class="text-muted" style="font-size:12px">protected</em>
            <?php else: ?>
              <form method="post" action="<?= BASE_URL ?>/admin/users.php" style="margin:0"
                    onsubmit="return confirm('<?= $u['is_suspended'] ? 'Unsuspend' : 'Suspend' ?> @<?= h($u['username']) ?>?');">
                <input type="hidden" name="action" value="toggle_suspend">
                <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                <button class="btn btn-outline btn-sm" type="submit">
                  <?= $u['is_suspended'] ? 'Unsuspend' : 'Suspend' ?>
                </button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($total_pages > 1): ?>
<div class="flex gap-2 mt-2" style="justify-content:center">
  <?php if ($page > 1): ?>
    <a class="btn btn-outline btn-sm" href="?filter=<?= h($filter) ?>&page=<?= $page - 1 ?>">← Previous</a>
  <?php endif; ?>
  <span class="text-muted" style="align-self:center">page <?= $page ?> of <?= $total_pages ?></span>
  <?php if ($page < $total_pages): ?>
    <a class="btn btn-outline btn-sm" href="?filter=<?= h($filter) ?>&page=<?= $page + 1 ?>">Next →</a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>