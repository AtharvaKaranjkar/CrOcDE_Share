<?php
/**
 * auth/login.php — Log in by username + password.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

if (is_logged_in()) {
    redirect(is_admin() ? '/admin/index.php' : '/dashboard.php');
}

$old = ['username' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $old['username'] = $username;

    if ($username === '' || $password === '') {
        flash('error', 'Please enter both username and password.');
    } else {
        $stmt = $conn->prepare(
            'SELECT user_id, username, password_hash, role, is_suspended
             FROM users WHERE username = ?'
        );
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password_hash'])) {
            // Anti-fixation: rotate the session ID on privilege change.
            session_regenerate_id(true);
            $_SESSION['user_id']      = (int)$user['user_id'];
            $_SESSION['username']     = $user['username'];
            $_SESSION['role']         = $user['role'];
            $_SESSION['is_suspended'] = (int)$user['is_suspended'];

            audit_log($conn, $_SESSION['user_id'], 'login', 'users',
                      $_SESSION['user_id'], "User logged in.");

            flash('success', 'Welcome back, ' . $user['username'] . '!');
            redirect($user['role'] === 'admin' ? '/admin/index.php' : '/dashboard.php');
        } else {
            flash('error', 'Invalid username or password.');
        }
    }
}

$page_title = 'Log in';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-wrap">
  <h1>Log in</h1>
  <div class="card">
    <form method="post" action="<?= BASE_URL ?>/auth/login.php">
      <div class="form-group">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" required autofocus
               value="<?= h($old['username']) ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Log in</button>
    </form>
  </div>
  <div class="auth-footer">
    Don't have an account?
    <a href="<?= BASE_URL ?>/auth/signup.php">Sign up</a>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>