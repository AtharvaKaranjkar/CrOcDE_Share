<?php
/**
 * auth/logout.php — End the session and bounce home.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

if (is_logged_in()) {
    audit_log($conn, current_user_id(), 'logout', 'users',
              current_user_id(), 'User logged out.');
}

// Wipe session data and destroy the session cookie.
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

// Start a fresh session purely so we can carry one flash message home.
session_start();
session_regenerate_id(true);
flash('success', 'You have been logged out.');
header('Location: ' . BASE_URL . '/');
exit;