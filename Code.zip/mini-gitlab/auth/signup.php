<?php
/**
 * auth/signup.php — Create a new user account.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

// Already logged in? Send them to their dashboard.
if (is_logged_in()) {
    redirect(is_admin() ? '/admin/index.php' : '/dashboard.php');
}

$errors = [];
$old = ['username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';
    $confirm  = $_POST['confirm']       ?? '';
    $old = ['username' => $username, 'email' => $email];

    // ---- Validation -----------------------------------------------
    if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        $errors[] = 'Username must be 3–50 characters, using letters, numbers, or underscores only.';
    }
    if (strcasecmp($username, 'admin') === 0) {
        $errors[] = 'That username is reserved.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) {
        $errors[] = 'Please enter a valid email address (max 100 chars).';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    // ---- Insert ---------------------------------------------------
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $conn->prepare(
                'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)'
            );
            $stmt->bind_param('sss', $username, $email, $hash);
            $stmt->execute();
            $new_id = $conn->insert_id;

            audit_log($conn, $new_id, 'user_signup', 'users', $new_id,
                      "User '{$username}' signed up.");

            flash('success', 'Account created! Please log in.');
            redirect('/auth/login.php');
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                if (stripos($e->getMessage(), 'username') !== false) {
                    $errors[] = 'That username is already taken.';
                } else {
                    $errors[] = 'That email is already registered.';
                }
            } else {
                $errors[] = 'Sign-up failed: ' . $e->getMessage();
            }
        }
    }
}

$page_title = 'Sign up';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-wrap">
  <h1>Create your account</h1>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-error">
      <?php foreach ($errors as $e): ?>
        <div><?= h($e) ?></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="card">
    <form method="post" action="<?= BASE_URL ?>/auth/signup.php">
      <div class="form-group">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" maxlength="50" required
               value="<?= h($old['username']) ?>">
        <div class="form-hint">3–50 chars · letters, numbers, underscores.</div>
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" maxlength="100" required
               value="<?= h($old['email']) ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required>
        <div class="form-hint">At least 6 characters.</div>
      </div>
      <div class="form-group">
        <label for="confirm">Confirm password</label>
        <input id="confirm" name="confirm" type="password" required>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Create account</button>
    </form>
  </div>

  <div class="auth-footer">
    Already have an account?
    <a href="<?= BASE_URL ?>/auth/login.php">Log in</a>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>