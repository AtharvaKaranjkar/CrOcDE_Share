<?php
/**
 * comments/delete.php — Soft-delete a comment (sets deleted_at).
 *
 * Authors can delete their own; admins can delete any.
 * Soft-delete keeps the thread structure intact.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
// Note: suspended users can still delete their own comments.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/');
}

$comment_id = (int)($_POST['comment_id'] ?? 0);
if ($comment_id <= 0) { flash('error', 'Invalid comment.'); redirect('/'); }

$stmt = $conn->prepare("SELECT repo_id, user_id, deleted_at FROM comments WHERE comment_id = ?");
$stmt->bind_param('i', $comment_id);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();
if (!$c) { flash('error', 'Comment not found.'); redirect('/'); }
if ($c['deleted_at']) { flash('error', 'Comment already deleted.'); redirect('/repos/view.php?id=' . $c['repo_id']); }

$me = current_user_id();
if ((int)$c['user_id'] !== (int)$me && !is_admin()) {
    flash('error', "You can only delete your own comments.");
    redirect('/repos/view.php?id=' . $c['repo_id']);
}

$stmt = $conn->prepare("UPDATE comments SET deleted_at = NOW() WHERE comment_id = ?");
$stmt->bind_param('i', $comment_id);
$stmt->execute();

audit_log($conn, $me, 'comment_delete', 'comments', $comment_id,
          "Deleted comment on repo #{$c['repo_id']}.");

flash('success', 'Comment deleted.');
redirect('/repos/view.php?id=' . $c['repo_id'] . '#comments');