<?php
/**
 * comments/post.php — Post a new comment or reply.
 *
 * Accepts POST: repo_id, body, parent_comment_id (optional for replies).
 * Suspended users blocked.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/');
}

$repo_id   = (int)($_POST['repo_id'] ?? 0);
$body      = trim($_POST['body'] ?? '');
$parent_id = (int)($_POST['parent_comment_id'] ?? 0);
if ($parent_id === 0) $parent_id = null;

if ($repo_id <= 0) { flash('error', 'Invalid repository.'); redirect('/'); }
if ($body === '')  { flash('error', 'Comment cannot be empty.'); redirect('/repos/view.php?id=' . $repo_id); }
if (mb_strlen($body) > 2000) {
    flash('error', 'Comment too long (max 2000 chars).');
    redirect('/repos/view.php?id=' . $repo_id);
}

// Verify the repo exists and is viewable
$stmt = $conn->prepare("SELECT visibility, owner_id, deleted_at FROM repositories WHERE repo_id = ?");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || $repo['deleted_at']) {
    flash('error', 'Repo not found.'); redirect('/');
}

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);

$is_contributor = false;
if (!$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) {
    flash('error', "You can't comment on a private repository you don't have access to.");
    redirect('/');
}

// If replying, verify the parent comment exists and belongs to the same repo
if ($parent_id !== null) {
    $stmt = $conn->prepare("SELECT user_id FROM comments WHERE comment_id = ? AND repo_id = ?");
    $stmt->bind_param('ii', $parent_id, $repo_id);
    $stmt->execute();
    $parent = $stmt->get_result()->fetch_assoc();
    if (!$parent) {
        flash('error', 'Parent comment not found.');
        redirect('/repos/view.php?id=' . $repo_id);
    }
}

// Insert
try {
    if ($parent_id === null) {
        $stmt = $conn->prepare("
            INSERT INTO comments (repo_id, user_id, body) VALUES (?, ?, ?)
        ");
        $stmt->bind_param('iis', $repo_id, $me, $body);
    } else {
        $stmt = $conn->prepare("
            INSERT INTO comments (repo_id, user_id, parent_comment_id, body)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param('iiis', $repo_id, $me, $parent_id, $body);
    }
    $stmt->execute();
    $cid = $conn->insert_id;

    audit_log($conn, $me, 'comment_post', 'comments', $cid,
              "Posted comment on repo #{$repo_id}" . ($parent_id ? " (reply to #{$parent_id})" : ''));

    // Notify parent comment author if it's a reply (and not replying to yourself)
    if ($parent_id !== null && (int)$parent['user_id'] !== $me) {
        $msg = "@" . current_username() . " replied to your comment";
        $link = "/repos/view.php?id={$repo_id}#comment-{$cid}";
        $stmt2 = $conn->prepare("
            INSERT INTO notifications (user_id, type, message, link)
            VALUES (?, 'comment_reply', ?, ?)
        ");
        $stmt2->bind_param('iss', $parent['user_id'], $msg, $link);
        $stmt2->execute();
    }

    flash('success', 'Comment posted.');
} catch (mysqli_sql_exception $e) {
    flash('error', 'Could not post: ' . $e->getMessage());
}

redirect('/repos/view.php?id=' . $repo_id . '#comments');