<?php
/**
 * config/db.php — Database connection & global configuration.
 *
 * Edit DB_USER/DB_PASS if your XAMPP MySQL has been customized.
 * Default XAMPP install: user "root" with empty password.
 */

// --- Site config ---------------------------------------------------
define('SITE_NAME', 'Mini-GitLab');

// BASE_URL is auto-detected so the project works no matter what
// folder you drop it into under htdocs.
if (!defined('BASE_URL')) {
    $script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $project_root_fs = dirname(__DIR__);
    $project_folder  = basename($project_root_fs);

    $pos = strpos($script_dir, '/' . $project_folder);
    if ($pos !== false) {
        define('BASE_URL', substr($script_dir, 0, $pos) . '/' . $project_folder);
    } else {
        define('BASE_URL', '');
    }
}

// --- DB config -----------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mini_gitlab');

// --- Connect -------------------------------------------------------
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die(
        '<h2 style="font-family:sans-serif">Database connection failed.</h2>'
      . '<p style="font-family:sans-serif">Make sure MySQL is running in XAMPP, '
      . 'and that the <code>mini_gitlab</code> database has been created '
      . '(load <code>sql/01_schema.sql</code> + <code>sql/02_seed.sql</code> '
      . 'via phpMyAdmin).</p>'
      . '<pre style="background:#222;color:#eee;padding:12px">'
      . htmlspecialchars($e->getMessage())
      . '</pre>'
    );
}