<?php
/**
 * dashboard.php — Signed-in user's home.
 *
 * Phase 3: full dashboard = owned UNION contributed UNION forked.
 * The role column tells you why each row is on the list.
 * Forked private repos are filtered out (visibility check in WHERE).
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
refresh_suspension_status($conn);

if (is_admin()) redirect('/admin/index.php');

$me = current_user_id();

// UNION query: combine owned + contributed + forked.
// UNION (not UNION ALL) removes duplicates if a user happens to be both
// contributor and forker of the same repo.
$sql = "
SELECT r.repo_id, r.name, r.language, r.visibility, r.view_count, r.updated_at,
       u.username AS owner_username,
       'owner' AS role,
       (SELECT MAX(version_number) FROM versions WHERE repo_id = r.repo_id) AS latest_version
FROM repositories r
JOIN users u ON u.user_id = r.owner_id
WHERE r.owner_id = ? AND r.deleted_at IS NULL

UNION

SELECT r.repo_id, r.name, r.language, r.visibility, r.view_count, r.updated_at,
       u.username AS owner_username,
       'contributor' AS role,
       (SELECT MAX(version_number) FROM versions WHERE repo_id = r.repo_id) AS latest_version
FROM repositories r
JOIN users u ON u.user_id = r.owner_id
JOIN repo_contributors rc ON rc.repo_id = r.repo_id
WHERE rc.user_id = ? AND r.deleted_at IS NULL

UNION

SELECT r.repo_id, r.name, r.language, r.visibility, r.view_count, r.updated_at,
       u.username AS owner_username,
       'fork' AS role,
       (SELECT MAX(version_number) FROM versions WHERE repo_id = r.repo_id) AS latest_version
FROM repositories r
JOIN users u ON u.user_id = r.owner_id
JOIN forks f ON f.repo_id = r.repo_id
WHERE f.user_id = ?
  AND r.deleted_at IS NULL
  AND r.visibility = 'public'      -- private flip hides the fork

ORDER BY updated_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param('iii', $me, $me, $me);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// If the same repo appears in two source sets (e.g. owner+contributor would
// be impossible, but fork+contributor IS possible per your spec), MySQL UNION
// dedupes by all columns — but the 'role' column differs, so both will show.
// We collapse here in PHP, keeping the "stronger" role.
$rank = ['owner' => 0, 'contributor' => 1, 'fork' => 2];
$best = [];
foreach ($rows as $r) {
    $id = $r['repo_id'];
    if (!isset($best[$id]) || $rank[$r['role']] < $rank[$best[$id]['role']]) {
        $best[$id] = $r;
    }
}
$rows = array_values($best);
usort($rows, fn($a, $b) => strtotime($b['updated_at']) <=> strtotime($a['updated_at']));

$page_title = 'Dashboard';
require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between mb-2">
  <div>
    <h1 class="mt-0 mb-0">Welcome, <?= h(current_username()) ?> 👋</h1>
    <p class="text-muted mt-1 mb-0">Repos you own, contribute to, or forked.</p>
  </div>
  <a class="btn btn-primary" href="<?= BASE_URL ?>/repos/create.php">+ New repository</a>
</div>

<div class="card">
  <h2 class="card-title">Your repositories (<?= count($rows) ?>)</h2>

  <?php if (empty($rows)): ?>
    <p class="text-muted mb-0">
      Nothing here yet — <a href="<?= BASE_URL ?>/repos/create.php">create a repo</a>
      or fork a public one from <a href="<?= BASE_URL ?>/">explore</a>.
    </p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Owner</th>
          <th>Role</th>
          <th>Language</th>
          <th>Visibility</th>
          <th>Versions</th>
          <th>Updated</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td>
              <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$r['repo_id'] ?>">
                <?= h($r['name']) ?>
              </a>
            </td>
            <td>
              <?php if ($r['owner_username'] === current_username()): ?>
                you
              <?php else: ?>
                <a href="<?= BASE_URL ?>/profile.php?user=<?= h($r['owner_username']) ?>">
                  @<?= h($r['owner_username']) ?>
                </a>
              <?php endif; ?>
            </td>
            <td>
              <span class="badge <?= $r['role'] === 'owner' ? 'badge-crimson' : '' ?>">
                <?= h($r['role']) ?>
              </span>
            </td>
            <td><span class="badge badge-crimson"><?= h($r['language']) ?></span></td>
            <td>
              <span class="badge <?= $r['visibility'] === 'public' ? 'badge-public' : 'badge-private' ?>">
                <?= h($r['visibility']) ?>
              </span>
            </td>
            <td>v<?= (int)$r['latest_version'] ?></td>
            <td class="text-muted"><?= h(date('M j, Y', strtotime($r['updated_at']))) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>