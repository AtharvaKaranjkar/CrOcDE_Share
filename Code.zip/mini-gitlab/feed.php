<?php
/**
 * feed.php — Activity feed of users you follow.
 *
 * Combines two streams:
 *   - New repositories from followed users
 *   - New versions on repos owned by followed users
 * Both sorted by recency. Limited to last 50 events.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$me = current_user_id();

// Get followed user IDs
$stmt = $conn->prepare("SELECT followee_id FROM follows WHERE follower_id = ?");
$stmt->bind_param('i', $me);
$stmt->execute();
$followee_ids = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'followee_id');

// UNION query: new repos + new versions from followed users
$events = [];
if (!empty($followee_ids)) {
    $placeholders = implode(',', array_fill(0, count($followee_ids), '?'));
    $types = str_repeat('i', count($followee_ids));

    $sql = "
        SELECT 'new_repo' AS event_type,
               r.repo_id, r.name AS repo_name,
               NULL AS version_number,
               u.username AS actor,
               r.created_at AS event_time
        FROM repositories r
        JOIN users u ON u.user_id = r.owner_id
        WHERE r.owner_id IN ($placeholders)
          AND r.visibility = 'public'
          AND r.deleted_at IS NULL

        UNION ALL

        SELECT 'new_version' AS event_type,
               r.repo_id, r.name AS repo_name,
               v.version_number,
               u.username AS actor,
               v.created_at AS event_time
        FROM versions v
        JOIN repositories r ON r.repo_id = v.repo_id
        JOIN users u ON u.user_id = v.author_id
        WHERE v.author_id IN ($placeholders)
          AND r.visibility = 'public'
          AND r.deleted_at IS NULL
          AND v.version_number > 1   -- skip the auto-v1 from repo_create

        ORDER BY event_time DESC
        LIMIT 50
    ";

    // Bind followee_ids twice (once for repos, once for versions)
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types . $types, ...array_merge($followee_ids, $followee_ids));
    $stmt->execute();
    $events = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$page_title = 'Activity feed';
require_once __DIR__ . '/includes/header.php';
?>

<h1 class="mt-0">Activity feed</h1>
<p class="text-muted">Recent activity from people you follow.</p>

<?php if (empty($followee_ids)): ?>
  <div class="card">
    <p class="text-muted mb-0">
      You aren't following anyone yet. Visit a
      <a href="<?= BASE_URL ?>/">user's profile</a> and click Follow to start.
    </p>
  </div>
<?php elseif (empty($events)): ?>
  <div class="card">
    <p class="text-muted mb-0">
      No recent public activity from the <?= count($followee_ids) ?> user(s) you follow.
    </p>
  </div>
<?php else: ?>
  <div class="card">
    <h2 class="card-title">Recent events (<?= count($events) ?>)</h2>
    <?php foreach ($events as $e): ?>
      <div style="padding:12px 0;border-bottom:1px solid var(--grey-200)">
        <strong>
          <a href="<?= BASE_URL ?>/profile.php?user=<?= h($e['actor']) ?>">
            @<?= h($e['actor']) ?>
          </a>
        </strong>
        <?php if ($e['event_type'] === 'new_repo'): ?>
          created a new repository
          <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$e['repo_id'] ?>">
            <strong><?= h($e['repo_name']) ?></strong>
          </a>
        <?php else: ?>
          pushed v<?= (int)$e['version_number'] ?> to
          <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$e['repo_id'] ?>">
            <strong><?= h($e['repo_name']) ?></strong>
          </a>
        <?php endif; ?>
        <div class="text-muted" style="font-size:12px;margin-top:2px">
          <?= h(date('M j, Y g:i A', strtotime($e['event_time']))) ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>