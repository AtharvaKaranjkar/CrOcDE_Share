<?php
/**
 * follow.php — Follow or unfollow a user.
 *
 * Toggle action: if not following, follow. If already following, unfollow.
 * Reached via GET ?user=username&action=follow|unfollow.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
refresh_suspension_status($conn);
// Note: suspended users CAN follow/unfollow (it's not a "write" in the
// content sense; it doesn't affect other users' repos or comments).

$username = trim($_GET['user']   ?? '');
$action   = $_GET['action'] ?? 'follow';

if ($username === '') { http_response_code(400); die('No user specified.'); }
if (!in_array($action, ['follow', 'unfollow'], true)) {
    http_response_code(400); die('Invalid action.');
}

// Look up the target user
$stmt = $conn->prepare("SELECT user_id, role FROM users WHERE username = ?");
$stmt->bind_param('s', $username);
$stmt->execute();
$target = $stmt->get_result()->fetch_assoc();
if (!$target) {
    flash('error', "User '{$username}' not found.");
    redirect('/');
}

$me = current_user_id();
$target_id = (int)$target['user_id'];

if ($target_id === $me) {
    flash('error', "You can't follow yourself.");
    redirect('/profile.php?user=' . urlencode($username));
}

if ($action === 'follow') {
    try {
        $stmt = $conn->prepare("INSERT INTO follows (follower_id, followee_id) VALUES (?, ?)");
        $stmt->bind_param('ii', $me, $target_id);
        $stmt->execute();
        audit_log($conn, $me, 'follow_user', 'users', $target_id, "Followed @{$username}.");

        // Notify the followed user
        $msg = "@" . current_username() . " started following you.";
        $link = "/profile.php?user=" . current_username();
        $stmt2 = $conn->prepare("
            INSERT INTO notifications (user_id, type, message, link)
            VALUES (?, 'new_follower', ?, ?)
        ");
        $stmt2->bind_param('iss', $target_id, $msg, $link);
        $stmt2->execute();

        flash('success', "You are now following @{$username}.");
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() === 1062) {
            flash('error', "You're already following @{$username}.");
        } else {
            flash('error', "Couldn't follow: " . $e->getMessage());
        }
    }
} else {
    $stmt = $conn->prepare("DELETE FROM follows WHERE follower_id = ? AND followee_id = ?");
    $stmt->bind_param('ii', $me, $target_id);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        audit_log($conn, $me, 'unfollow_user', 'users', $target_id, "Unfollowed @{$username}.");
        flash('success', "Unfollowed @{$username}.");
    } else {
        flash('error', "You weren't following @{$username}.");
    }
}

redirect('/profile.php?user=' . urlencode($username));