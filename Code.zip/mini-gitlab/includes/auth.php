<?php
/**
 * includes/auth.php — Session & access-control helpers.
 *
 * ALWAYS include this BEFORE producing any HTML output, because
 * session_start() must run before headers are sent.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

// -------------------------------------------------------------------
// Session getters
// -------------------------------------------------------------------
function current_user_id() { return $_SESSION['user_id']  ?? null; }
function current_username() { return $_SESSION['username'] ?? null; }
function current_role()    { return $_SESSION['role']    ?? null; }
function is_logged_in()    { return isset($_SESSION['user_id']); }
function is_admin()        { return current_role() === 'admin'; }
function is_suspended()    { return !empty($_SESSION['is_suspended']); }

// -------------------------------------------------------------------
// Gates
// -------------------------------------------------------------------
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['_flash']['error'] = 'Please log in first.';
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        die('Access denied. Admin only.');
    }
}

/**
 * Refresh the user's suspension flag from the DB on every page load
 * (so an admin's suspend action takes effect immediately).
 */
function refresh_suspension_status(mysqli $conn) {
    if (!is_logged_in()) return;
    $uid = current_user_id();
    $stmt = $conn->prepare('SELECT is_suspended FROM users WHERE user_id = ?');
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row === null) {
        $_SESSION = [];
        session_destroy();
        header('Location: ' . BASE_URL . '/');
        exit;
    }
    $_SESSION['is_suspended'] = (int)$row['is_suspended'];
}

/**
 * Block write actions for suspended users. View-only pages don't need it.
 */
function block_if_suspended() {
    if (is_suspended()) {
        http_response_code(403);
        die('Your account is suspended. You cannot perform this action.');
    }
}