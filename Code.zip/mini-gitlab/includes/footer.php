</main>

<footer class="footer">
  <div class="container">
    <small>© <?= date('Y') ?> <?= h(SITE_NAME) ?> · A DBMS project</small>
  </div>
</footer>

</body>
</html>