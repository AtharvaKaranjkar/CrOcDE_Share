<?php
/**
 * includes/header.php — Page chrome.
 *
 * Phase 6 additions:
 *   - Feed link
 *   - Notification bell with unread count
 */
$page_title = $page_title ?? SITE_NAME;

// Unread notification count (only if logged in)
$_unread_n = 0;
if (is_logged_in()) {
    $_stmt = $conn->prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0");
    $_uid = current_user_id();
    $_stmt->bind_param('i', $_uid);
    $_stmt->execute();
    $_unread_n = (int)$_stmt->get_result()->fetch_assoc()['n'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= h($page_title) ?> · <?= h(SITE_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<nav class="topnav">
  <div class="container nav-inner">
    <a class="brand" href="<?= BASE_URL ?>/"><?= h(SITE_NAME) ?></a>
    <div class="nav-links">
      <a href="<?= BASE_URL ?>/">Explore</a>
      <?php if (is_logged_in()): ?>
        <?php if (is_admin()): ?>
          <a href="<?= BASE_URL ?>/admin/index.php">Admin</a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
          <a href="<?= BASE_URL ?>/feed.php">Feed</a>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>/notifications.php" style="position:relative">
          🔔
          <?php if ($_unread_n > 0): ?>
            <span class="badge badge-crimson" style="position:absolute;top:-6px;right:-10px;font-size:10px;padding:1px 6px">
              <?= $_unread_n ?>
            </span>
          <?php endif; ?>
        </a>
        <span class="nav-user">
          @<?= h(current_username()) ?>
          <?php if (is_admin()): ?><span class="badge badge-admin">admin</span><?php endif; ?>
        </span>
        <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/auth/logout.php">Log out</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/auth/login.php">Log in</a>
        <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>/auth/signup.php">Sign up</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<?php if (is_suspended()): ?>
<div class="banner banner-danger">
  <div class="container">
    <strong>Your account is suspended.</strong>
    You can still browse, but you cannot create repositories, post comments,
    or propose changes.
  </div>
</div>
<?php endif; ?>

<?php
$err = flash('error');
$ok  = flash('success');
if ($err || $ok):
?>
<div class="container">
  <?php if ($err): ?><div class="alert alert-error"><?= h($err) ?></div><?php endif; ?>
  <?php if ($ok):  ?><div class="alert alert-success"><?= h($ok)  ?></div><?php endif; ?>
</div>
<?php endif; ?>

<main class="container">