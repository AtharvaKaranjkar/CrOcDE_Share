<?php
/**
 * includes/helpers.php — Small utility helpers used across the app.
 */

/** Safe HTML escape. Always use this when outputting user-supplied text. */
function h($str) {
    return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Flash messages — survive exactly one redirect.
 *
 *   flash('error', 'Bad password');   // set
 *   $msg = flash('error');            // get and consume
 */
function flash($key, $value = null) {
    if ($value === null) {
        $val = $_SESSION['_flash'][$key] ?? null;
        if (isset($_SESSION['_flash'][$key])) {
            unset($_SESSION['_flash'][$key]);
        }
        return $val;
    }
    $_SESSION['_flash'][$key] = $value;
}

/** Redirect to a path relative to BASE_URL, then halt. */
function redirect($path) {
    header('Location: ' . BASE_URL . $path);
    exit;
}

/**
 * Append a row to audit_log. All admin actions, logins, signups,
 * suspensions, and ownership transfers go through here.
 */
function audit_log(mysqli $conn, $actor_id, $action,
                   $target_type = null, $target_id = null, $details = null) {
    $stmt = $conn->prepare(
        'INSERT INTO audit_log (actor_id, action, target_type, target_id, details)
         VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('issis', $actor_id, $action, $target_type, $target_id, $details);
    $stmt->execute();
}