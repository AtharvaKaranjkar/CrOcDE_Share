<?php
/**
 * index.php — Landing page + public explore feed + trending.
 *
 * Phase 6: adds "Trending by language" using RANK() OVER PARTITION BY.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$LANGUAGES = ['C++','C','Python','Java','JavaScript','Go','Rust','SQL','Other'];

$q    = trim($_GET['q']    ?? '');
$lang = trim($_GET['lang'] ?? '');
$tag  = trim($_GET['tag']  ?? '');

// ---- Main search query ----
$sql = "SELECT DISTINCT r.repo_id, r.name, r.language, r.view_count, r.updated_at,
               u.username AS owner_username
         FROM repositories r
         JOIN users u ON u.user_id = r.owner_id ";
if ($tag !== '') {
    $sql .= "JOIN repo_tags rt ON rt.repo_id = r.repo_id
             JOIN tags t ON t.tag_id = rt.tag_id ";
}
$sql .= "WHERE r.visibility = 'public' AND r.deleted_at IS NULL ";

$types = '';
$params = [];
if ($q !== '') {
    $sql .= " AND r.name LIKE ?";
    $types .= 's'; $params[] = '%' . $q . '%';
}
if ($lang !== '' && in_array($lang, $LANGUAGES, true)) {
    $sql .= " AND r.language = ?";
    $types .= 's'; $params[] = $lang;
}
if ($tag !== '') {
    $sql .= " AND t.name = ?";
    $types .= 's'; $params[] = $tag;
}
$sql .= " ORDER BY r.updated_at DESC LIMIT 50";

$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$repos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ---- Trending: top 3 per language by like count, using RANK() ----
// Window function: RANK() OVER (PARTITION BY language ORDER BY like_count DESC)
$trending_sql = "
    WITH repo_likes AS (
        SELECT r.repo_id, r.name, r.language, r.view_count,
               u.username AS owner_username,
               COALESCE(SUM(CASE WHEN rx.type = 'like' THEN 1 ELSE 0 END), 0) AS like_count
        FROM repositories r
        JOIN users u ON u.user_id = r.owner_id
        LEFT JOIN reactions rx ON rx.repo_id = r.repo_id
        WHERE r.visibility = 'public' AND r.deleted_at IS NULL
        GROUP BY r.repo_id, r.name, r.language, r.view_count, u.username
    ),
    ranked AS (
        SELECT *, RANK() OVER (PARTITION BY language ORDER BY like_count DESC, view_count DESC) AS rk
        FROM repo_likes
    )
    SELECT * FROM ranked
    WHERE rk <= 3 AND like_count > 0
    ORDER BY language, rk
";
$trending = $conn->query($trending_sql)->fetch_all(MYSQLI_ASSOC);

// Group trending by language
$by_lang = [];
foreach ($trending as $t) {
    $by_lang[$t['language']][] = $t;
}

$all_tags = $conn->query("SELECT name FROM tags ORDER BY name")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Explore';
require_once __DIR__ . '/includes/header.php';
?>

<?php if (!is_logged_in()): ?>
<section class="hero">
  <h1><span class="accent">Mini</span>-GitLab</h1>
  <p>A lightweight code-sharing platform: create repositories, invite contributors,
  propose changes, and review version history — all in one place.</p>
  <div class="hero-buttons">
    <a class="btn btn-primary" href="<?= BASE_URL ?>/auth/signup.php">Get started</a>
    <a class="btn btn-outline" href="<?= BASE_URL ?>/auth/login.php">Log in</a>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($by_lang)): ?>
<div class="card">
  <h2 class="card-title">🔥 Trending by language</h2>
  <p class="text-muted">Top 3 most-liked repositories in each language.</p>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">
    <?php foreach ($by_lang as $L => $items): ?>
      <div>
        <strong><?= h($L) ?></strong>
        <ol style="margin:6px 0 0 20px;padding:0">
          <?php foreach ($items as $r): ?>
            <li style="margin:4px 0">
              <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$r['repo_id'] ?>">
                <?= h($r['name']) ?>
              </a>
              <span class="text-muted" style="font-size:12px">
                · @<?= h($r['owner_username']) ?>
                · 👍 <?= (int)$r['like_count'] ?>
              </span>
            </li>
          <?php endforeach; ?>
        </ol>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <h2 class="card-title">Explore public repositories</h2>

  <form method="get" action="<?= BASE_URL ?>/" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div class="form-group" style="flex:1;min-width:220px;margin-bottom:0">
      <label for="q">Search by name</label>
      <input id="q" name="q" type="text" maxlength="100" value="<?= h($q) ?>"
             placeholder="factorial, todo, sort...">
    </div>
    <div class="form-group" style="min-width:160px;margin-bottom:0">
      <label for="lang">Language</label>
      <select id="lang" name="lang">
        <option value="">All languages</option>
        <?php foreach ($LANGUAGES as $L): ?>
          <option value="<?= h($L) ?>" <?= $lang === $L ? 'selected' : '' ?>><?= h($L) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group" style="min-width:160px;margin-bottom:0">
      <label for="tag">Tag</label>
      <select id="tag" name="tag">
        <option value="">All tags</option>
        <?php foreach ($all_tags as $t): ?>
          <option value="<?= h($t['name']) ?>" <?= $tag === $t['name'] ? 'selected' : '' ?>>
            <?= h($t['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-primary" type="submit">Search</button>
      <?php if ($q !== '' || $lang !== '' || $tag !== ''): ?>
        <a class="btn btn-outline" href="<?= BASE_URL ?>/">Clear</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="card">
  <h2 class="card-title">
    Results <span class="text-muted" style="font-weight:400">(<?= count($repos) ?>)</span>
  </h2>

  <?php if (empty($repos)): ?>
    <p class="text-muted mb-0">No public repositories match your filters.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Owner</th>
          <th>Language</th>
          <th>Views</th>
          <th>Updated</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($repos as $r): ?>
          <tr>
            <td>
              <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$r['repo_id'] ?>">
                <?= h($r['name']) ?>
              </a>
            </td>
            <td>@<?= h($r['owner_username']) ?></td>
            <td><span class="badge badge-crimson"><?= h($r['language']) ?></span></td>
            <td><?= (int)$r['view_count'] ?></td>
            <td class="text-muted"><?= h(date('M j, Y', strtotime($r['updated_at']))) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>