<?php
/**
 * notifications.php — User's notification inbox.
 *
 * Lists all notifications (newest first), supports "mark as read" and
 * "mark all read". Pagination via LIMIT/OFFSET (DBMS concept).
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$me = current_user_id();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'mark_all_read') {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
        $stmt->bind_param('i', $me);
        $stmt->execute();
        flash('success', 'All notifications marked as read.');
        redirect('/notifications.php');
    } elseif ($action === 'mark_read') {
        $nid = (int)($_POST['notif_id'] ?? 0);
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE notif_id = ? AND user_id = ?");
        $stmt->bind_param('ii', $nid, $me);
        $stmt->execute();
        redirect('/notifications.php');
    }
}

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Total count
$stmt = $conn->prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ?");
$stmt->bind_param('i', $me);
$stmt->execute();
$total = (int)$stmt->get_result()->fetch_assoc()['n'];
$total_pages = max(1, (int)ceil($total / $per_page));

// Fetch this page
$stmt = $conn->prepare("
    SELECT notif_id, type, message, link, is_read, created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->bind_param('iii', $me, $per_page, $offset);
$stmt->execute();
$notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = 'Notifications';
require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between mb-2">
  <div>
    <h1 class="mt-0 mb-0">Notifications</h1>
    <p class="text-muted mt-1 mb-0">
      <?= $total ?> total · page <?= $page ?> of <?= $total_pages ?>
    </p>
  </div>
  <?php if ($total > 0): ?>
    <form method="post" action="<?= BASE_URL ?>/notifications.php" style="margin:0">
      <input type="hidden" name="action" value="mark_all_read">
      <button class="btn btn-outline" type="submit">Mark all read</button>
    </form>
  <?php endif; ?>
</div>

<div class="card">
  <?php if (empty($notifications)): ?>
    <p class="text-muted mb-0">No notifications yet.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Status</th>
          <th>Message</th>
          <th>When</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($notifications as $n): ?>
          <tr style="<?= $n['is_read'] ? 'opacity:0.6' : '' ?>">
            <td>
              <?php if (!$n['is_read']): ?>
                <span class="badge badge-crimson">new</span>
              <?php else: ?>
                <span class="text-muted">read</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if (!empty($n['link'])): ?>
                <a href="<?= BASE_URL . h($n['link']) ?>"><?= h($n['message']) ?></a>
              <?php else: ?>
                <?= h($n['message']) ?>
              <?php endif; ?>
              <div class="text-muted" style="font-size:11px;margin-top:2px"><?= h($n['type']) ?></div>
            </td>
            <td class="text-muted">
              <?= h(date('M j, Y g:i A', strtotime($n['created_at']))) ?>
            </td>
            <td class="text-right">
              <?php if (!$n['is_read']): ?>
                <form method="post" action="<?= BASE_URL ?>/notifications.php" style="margin:0">
                  <input type="hidden" name="action" value="mark_read">
                  <input type="hidden" name="notif_id" value="<?= (int)$n['notif_id'] ?>">
                  <button class="btn btn-outline btn-sm" type="submit">Mark read</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php if ($total_pages > 1): ?>
<div class="flex gap-2 mt-2" style="justify-content:center">
  <?php if ($page > 1): ?>
    <a class="btn btn-outline btn-sm" href="?page=<?= $page - 1 ?>">← Previous</a>
  <?php endif; ?>
  <span class="text-muted" style="align-self:center">page <?= $page ?> of <?= $total_pages ?></span>
  <?php if ($page < $total_pages): ?>
    <a class="btn btn-outline btn-sm" href="?page=<?= $page + 1 ?>">Next →</a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>