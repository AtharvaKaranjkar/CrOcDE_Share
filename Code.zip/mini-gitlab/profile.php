<?php
/**
 * profile.php — Public profile page.
 *
 * Phase 6 additions:
 *   - Follow / Unfollow button
 *   - Followers and following counts
 *   - List of who they follow / who follows them (collapsible)
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$username = trim($_GET['user'] ?? '');
if ($username === '') { http_response_code(400); die('No user specified.'); }

$stmt = $conn->prepare("
    SELECT user_id, username, role, is_suspended, created_at
    FROM users WHERE username = ?
");
$stmt->bind_param('s', $username);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();
if (!$u) { http_response_code(404); die('User not found.'); }

$me = current_user_id();
$is_me    = $me && ((int)$me === (int)$u['user_id']);
$is_admin = is_admin();
$user_id  = (int)$u['user_id'];

// Am I following them?
$i_follow = false;
if ($me && !$is_me) {
    $stmt = $conn->prepare("SELECT 1 FROM follows WHERE follower_id = ? AND followee_id = ?");
    $stmt->bind_param('ii', $me, $user_id);
    $stmt->execute();
    $i_follow = (bool)$stmt->get_result()->fetch_row();
}

// Their repos
$show_private = $is_me || $is_admin;
$sql = "SELECT repo_id, name, language, visibility, view_count, updated_at,
               (SELECT MAX(version_number) FROM versions WHERE repo_id = r.repo_id) AS latest_version
        FROM repositories r
        WHERE owner_id = ? AND deleted_at IS NULL "
     . ($show_private ? '' : " AND visibility = 'public' ")
     . "ORDER BY updated_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$repos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Aggregate stats including follow counts
$stmt = $conn->prepare("
    SELECT
      (SELECT COUNT(*) FROM repositories WHERE owner_id = ? AND deleted_at IS NULL) AS owned,
      (SELECT COUNT(*) FROM repo_contributors WHERE user_id = ?) AS contributed,
      (SELECT COUNT(*) FROM forks WHERE user_id = ?) AS forked,
      (SELECT COUNT(*) FROM follows WHERE followee_id = ?) AS followers,
      (SELECT COUNT(*) FROM follows WHERE follower_id = ?) AS following
");
$stmt->bind_param('iiiii', $user_id, $user_id, $user_id, $user_id, $user_id);
$stmt->execute();
$counts = $stmt->get_result()->fetch_assoc();

// Lists of followers / following
$stmt = $conn->prepare("
    SELECT u.username FROM follows f
    JOIN users u ON u.user_id = f.follower_id
    WHERE f.followee_id = ? ORDER BY f.followed_at DESC LIMIT 100
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$followers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$stmt = $conn->prepare("
    SELECT u.username FROM follows f
    JOIN users u ON u.user_id = f.followee_id
    WHERE f.follower_id = ? ORDER BY f.followed_at DESC LIMIT 100
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$following = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = '@' . $u['username'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between mb-2">
  <div>
    <h1 class="mt-0 mb-0">
      @<?= h($u['username']) ?>
      <?php if ($u['role'] === 'admin'): ?>
        <span class="badge badge-admin">admin</span>
      <?php endif; ?>
      <?php if ($u['is_suspended']): ?>
        <span class="badge" style="background:#fdecea;color:#c62828">suspended</span>
      <?php endif; ?>
    </h1>
    <p class="text-muted mt-1 mb-0">
      Joined <?= h(date('M Y', strtotime($u['created_at']))) ?> ·
      <?= (int)$counts['owned'] ?> owned ·
      <?= (int)$counts['contributed'] ?> contributing ·
      <?= (int)$counts['forked'] ?> forked ·
      <strong><?= (int)$counts['followers'] ?></strong> followers ·
      <strong><?= (int)$counts['following'] ?></strong> following
    </p>
  </div>

  <?php if (is_logged_in() && !$is_me && !is_admin() && $u['role'] !== 'admin'): ?>
    <a class="btn <?= $i_follow ? 'btn-outline' : 'btn-primary' ?>"
       href="<?= BASE_URL ?>/follow.php?user=<?= h($u['username']) ?>&action=<?= $i_follow ? 'unfollow' : 'follow' ?>">
      <?= $i_follow ? 'Unfollow' : 'Follow' ?>
    </a>
  <?php endif; ?>
</div>

<div class="card">
  <h2 class="card-title">
    <?= $show_private ? 'Repositories' : 'Public repositories' ?>
    <span class="text-muted" style="font-weight:400">(<?= count($repos) ?>)</span>
  </h2>

  <?php if (empty($repos)): ?>
    <p class="text-muted mb-0">No repositories to show.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Language</th>
          <?php if ($show_private): ?><th>Visibility</th><?php endif; ?>
          <th>Versions</th>
          <th>Updated</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($repos as $r): ?>
          <tr>
            <td>
              <a href="<?= BASE_URL ?>/repos/view.php?id=<?= (int)$r['repo_id'] ?>">
                <?= h($r['name']) ?>
              </a>
            </td>
            <td><span class="badge badge-crimson"><?= h($r['language']) ?></span></td>
            <?php if ($show_private): ?>
              <td>
                <span class="badge <?= $r['visibility'] === 'public' ? 'badge-public' : 'badge-private' ?>">
                  <?= h($r['visibility']) ?>
                </span>
              </td>
            <?php endif; ?>
            <td>v<?= (int)$r['latest_version'] ?></td>
            <td class="text-muted"><?= h(date('M j, Y', strtotime($r['updated_at']))) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="card">
    <h2 class="card-title">Followers (<?= (int)$counts['followers'] ?>)</h2>
    <?php if (empty($followers)): ?>
      <p class="text-muted mb-0">No followers yet.</p>
    <?php else: ?>
      <?php foreach ($followers as $f): ?>
        <a href="<?= BASE_URL ?>/profile.php?user=<?= h($f['username']) ?>"
           style="display:inline-block;margin-right:8px">@<?= h($f['username']) ?></a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2 class="card-title">Following (<?= (int)$counts['following'] ?>)</h2>
    <?php if (empty($following)): ?>
      <p class="text-muted mb-0">Not following anyone yet.</p>
    <?php else: ?>
      <?php foreach ($following as $f): ?>
        <a href="<?= BASE_URL ?>/profile.php?user=<?= h($f['username']) ?>"
           style="display:inline-block;margin-right:8px">@<?= h($f['username']) ?></a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>