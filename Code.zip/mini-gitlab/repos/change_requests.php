<?php
/**
 * repos/change_requests.php — View pending change requests.
 *
 * Owner sees all pending requests.
 * Contributor/viewer sees only their own.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);

// Fetch change requests
if ($is_owner || is_admin()) {
    // Owner/admin: all pending requests
    $stmt = $conn->prepare("
        SELECT cr.*, u.username AS requester_name
        FROM change_requests cr
        JOIN users u ON u.user_id = cr.requester_id
        WHERE cr.repo_id = ? AND cr.status = 'pending'
        ORDER BY cr.created_at ASC
    ");
    $stmt->bind_param('i', $repo_id);
} else {
    // Non-owner: only their own
    $stmt = $conn->prepare("
        SELECT cr.*, u.username AS requester_name
        FROM change_requests cr
        JOIN users u ON u.user_id = cr.requester_id
        WHERE cr.repo_id = ? AND cr.requester_id = ?
        ORDER BY cr.created_at ASC
    ");
    $stmt->bind_param('ii', $repo_id, $me);
}
$stmt->execute();
$requests = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = 'Change requests · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Change requests
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<?php if (!$is_owner && !is_admin()): ?>
  <div class="alert" style="background:#fff8e1;border-color:#ffd54f;color:#7c5c00">
    You can only see your own pending change requests here.
  </div>
<?php endif; ?>

<div class="card">
  <h2 class="card-title">Pending requests (<?= count($requests) ?>)</h2>

  <?php if (empty($requests)): ?>
    <p class="text-muted mb-0">No pending change requests.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Requested by</th>
          <th>Submitted</th>
          <th>Code preview</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($requests as $cr): ?>
          <tr>
            <td>
              <a href="<?= BASE_URL ?>/profile.php?user=<?= h($cr['requester_name']) ?>">
                @<?= h($cr['requester_name']) ?>
              </a>
            </td>
            <td class="text-muted"><?= h(date('M j, Y g:i A', strtotime($cr['created_at']))) ?></td>
            <td>
              <code style="font-size:12px"><?= h(mb_substr($cr['proposed_code'], 0, 60)) ?>...</code>
            </td>
            <td class="text-right">
              <a class="btn btn-outline btn-sm"
                 href="<?= BASE_URL ?>/repos/review_change.php?id=<?= $repo_id ?>&req=<?= (int)$cr['request_id'] ?>">
                Review
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>