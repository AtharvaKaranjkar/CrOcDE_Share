<?php
/**
 * repos/compare.php — Compare two versions side-by-side.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$repo_id = (int)($_GET['id']   ?? 0);
$from_v  = (int)($_GET['from'] ?? 0);
$to_v    = (int)($_GET['to']   ?? 0);
if ($repo_id <= 0 || $from_v <= 0 || $to_v <= 0) {
    http_response_code(400); die('Invalid comparison.');
}

// Repo check
$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ?");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || ($repo['deleted_at'] && !is_admin())) {
    http_response_code(404); die('Repo not found.');
}

$me = current_user_id();
$is_owner = $me && ((int)$repo['owner_id'] === (int)$me);
$is_contributor = false;
if ($me && !$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) { http_response_code(403); die('Private repository.'); }

// Fetch both versions
$stmt = $conn->prepare("
    SELECT version_number, code, author_id
    FROM versions WHERE repo_id = ? AND version_number IN (?, ?)
");
$stmt->bind_param('iii', $repo_id, $from_v, $to_v);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
if (count($rows) !== 2) { http_response_code(404); die('One or both versions not found.'); }

$from = null; $to = null;
foreach ($rows as $r) {
    if ((int)$r['version_number'] === $from_v) $from = $r;
    if ((int)$r['version_number'] === $to_v)   $to   = $r;
}

$page_title = "Compare v{$from_v}…v{$to_v} · " . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Compare v<?= $from_v ?> → v<?= $to_v ?>
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<p class="text-muted">
  Showing differences between version <?= $from_v ?> and version <?= $to_v ?>.
</p>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="card">
    <strong>Version <?= $from_v ?></strong> (<?= mb_strlen($from['code']) ?> chars)
    <pre class="code-block" style="margin-top:8px"><?= h($from['code']) ?></pre>
  </div>
  <div class="card">
    <strong>Version <?= $to_v ?></strong> (<?= mb_strlen($to['code']) ?> chars)
    <pre class="code-block" style="margin-top:8px"><?= h($to['code']) ?></pre>
  </div>
</div>

<div class="flex gap-2 mt-2">
  <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/versions.php?id=<?= $repo_id ?>">
    ← Back to version history
  </a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>