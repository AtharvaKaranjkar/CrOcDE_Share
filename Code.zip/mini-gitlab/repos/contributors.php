<?php
/**
 * repos/contributors.php — Add or remove contributors.
 *
 * - Add: form sends a username; we validate it exists, is not the
 *   owner, is not admin, and isn't already a contributor.
 * - Remove: by user_id (owner-only action).
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Fetch repo
$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
if ((int)$repo['owner_id'] !== (int)$me && !is_admin()) {
    http_response_code(403);
    die('Only the owner or an admin can manage contributors.');
}

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $username = trim($_POST['username'] ?? '');
    if ($username === '') {
        flash('error', "Enter a username.");
    } else {
        // Look up the user
        $stmt = $conn->prepare("
            SELECT user_id, role, is_suspended FROM users WHERE username = ?
        ");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();

        if (!$u) {
            flash('error', "No user named '{$username}'.");
        } elseif ($u['role'] === 'admin') {
            flash('error', "You can't add an admin as a contributor.");
        } elseif ((int)$u['user_id'] === (int)$repo['owner_id']) {
            flash('error', "That user is already the owner.");
        } else {
            try {
                $uid = (int)$u['user_id'];
                $stmt = $conn->prepare("
                    INSERT INTO repo_contributors (repo_id, user_id) VALUES (?, ?)
                ");
                $stmt->bind_param('ii', $repo_id, $uid);
                $stmt->execute();

                audit_log($conn, $me, 'contributor_added', 'repositories', $repo_id,
                          "Added @{$username} as contributor.");

                // Notify the new contributor
                $msg = "You were added as a contributor to '" . $repo['name'] . "'.";
                $link = "/repos/view.php?id={$repo_id}";
                $stmt2 = $conn->prepare("
                    INSERT INTO notifications (user_id, type, message, link)
                    VALUES (?, 'contributor_added', ?, ?)
                ");
                $stmt2->bind_param('iss', $uid, $msg, $link);
                $stmt2->execute();

                flash('success', "@{$username} added as contributor.");
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() === 1062) {
                    flash('error', "@{$username} is already a contributor.");
                } else {
                    flash('error', "Could not add: " . $e->getMessage());
                }
            }
        }
    }

} elseif ($action === 'remove') {
    $target_id = (int)($_POST['user_id'] ?? 0);
    if ($target_id <= 0) {
        flash('error', "Invalid user.");
    } else {
        $stmt = $conn->prepare("
            DELETE FROM repo_contributors WHERE repo_id = ? AND user_id = ?
        ");
        $stmt->bind_param('ii', $repo_id, $target_id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            audit_log($conn, $me, 'contributor_removed', 'repositories', $repo_id,
                      "Removed contributor user_id={$target_id}.");
            flash('success', "Contributor removed.");
        } else {
            flash('error', "That user wasn't a contributor.");
        }
    }
}

redirect('/repos/settings.php?id=' . $repo_id);