<?php
/**
 * repos/create.php — Create a new repository.
 *
 * Wraps the INSERT into repositories + INSERT into versions in a
 * single TRANSACTION so a repo is never created without its v1 code.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$LANGUAGES = ['C++','C','Python','Java','JavaScript','Go','Rust','SQL','Other'];

$errors = [];
$old = [
    'name'       => '',
    'language'   => 'C++',
    'visibility' => 'public',
    'code'       => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = trim($_POST['name'] ?? '');
    $language   = $_POST['language']   ?? '';
    $visibility = $_POST['visibility'] ?? 'public';
    $code       = $_POST['code']       ?? '';
    $old = compact('name', 'language', 'visibility', 'code');

    // ---- Validation ---------------------------------------------------
    if (!preg_match('/^[A-Za-z0-9 _.\-]{1,100}$/', $name)) {
        $errors[] = 'Repo name: 1–100 chars; letters, numbers, spaces, _ . -';
    }
    if (!in_array($language, $LANGUAGES, true)) {
        $errors[] = 'Pick a language from the list.';
    }
    if (!in_array($visibility, ['public', 'private'], true)) {
        $errors[] = 'Visibility must be public or private.';
    }
    if ($code === '') {
        $errors[] = 'The code field cannot be empty.';
    } elseif (mb_strlen($code) > 10000) {
        $errors[] = 'Code is too long (' . mb_strlen($code) . ' chars; max 10,000).';
    }

    // ---- Insert (TRANSACTION) -----------------------------------------
    if (empty($errors)) {
        $owner_id = current_user_id();
        $conn->begin_transaction();
        try {
            // 1. Create the repo
            $stmt = $conn->prepare(
                'INSERT INTO repositories (name, language, visibility, owner_id)
                 VALUES (?, ?, ?, ?)'
            );
            $stmt->bind_param('sssi', $name, $language, $visibility, $owner_id);
            $stmt->execute();
            $repo_id = $conn->insert_id;

            // 2. Insert version 1 with the initial code
            $lines = substr_count($code, "\n") + 1;
            $stmt2 = $conn->prepare(
                'INSERT INTO versions
                    (repo_id, version_number, code, author_id, lines_changed)
                 VALUES (?, 1, ?, ?, ?)'
            );
            $stmt2->bind_param('isii', $repo_id, $code, $owner_id, $lines);
            $stmt2->execute();

            // 3. Audit log
            audit_log($conn, $owner_id, 'repo_create', 'repositories', $repo_id,
                      "Created repo '{$name}' (lang={$language}, vis={$visibility}).");

            $conn->commit();
            flash('success', "Repository '{$name}' created.");
            redirect('/repos/view.php?id=' . $repo_id);
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $errors[] = 'Could not create repo: ' . $e->getMessage();
        }
    }
}

$page_title = 'New repository';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">New repository</h1>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">
    <?php foreach ($errors as $e): ?><div><?= h($e) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="card">
  <form method="post" action="<?= BASE_URL ?>/repos/create.php">
    <div class="form-group">
      <label for="name">Repository name</label>
      <input id="name" name="name" type="text" maxlength="100" required
             value="<?= h($old['name']) ?>">
      <div class="form-hint">e.g. "factorial", "binary search", "todo-app"</div>
    </div>

    <div class="form-group">
      <label for="language">Language</label>
      <select id="language" name="language" required>
        <?php foreach ($LANGUAGES as $L): ?>
          <option value="<?= h($L) ?>" <?= $old['language'] === $L ? 'selected' : '' ?>>
            <?= h($L) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-group">
      <label>Visibility</label>
      <label class="text-muted" style="font-weight:400">
        <input type="radio" name="visibility" value="public"
               <?= $old['visibility'] === 'public' ? 'checked' : '' ?>>
        Public — anyone can view
      </label><br>
      <label class="text-muted" style="font-weight:400">
        <input type="radio" name="visibility" value="private"
               <?= $old['visibility'] === 'private' ? 'checked' : '' ?>>
        Private — only owner and contributors
      </label>
    </div>

    <div class="form-group">
      <label for="code">Initial code (version 1)</label>
      <textarea id="code" name="code" required
                maxlength="10000"
                placeholder="// Paste your code here..."><?= h($old['code']) ?></textarea>
      <div class="form-hint">Maximum 10,000 characters.</div>
    </div>

    <div class="form-actions">
      <button class="btn btn-primary" type="submit">Create repository</button>
      <a class="btn btn-outline" href="<?= BASE_URL ?>/dashboard.php">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>