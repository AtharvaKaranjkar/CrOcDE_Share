<?php
/**
 * repos/edit.php — Edit code in a repository.
 *
 * - Owner save  → inserts a new version directly (TRANSACTION)
 * - Contributor or signed-in viewer save → inserts a row in
 *   change_requests with status='pending' for the owner to review.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Fetch the repo
$stmt = $conn->prepare("
    SELECT r.*, u.username AS owner_username
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE r.repo_id = ? AND r.deleted_at IS NULL
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);

// Contributor check
$is_contributor = false;
if (!$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

// Access: must be able to view to propose a change
$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor;
if (!$can_view) { http_response_code(403); die('You cannot edit this repo.'); }

// Fetch latest version's code (starting point for editor)
$stmt = $conn->prepare("
    SELECT version_number, code FROM versions
    WHERE repo_id = ? ORDER BY version_number DESC LIMIT 1
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$latest = $stmt->get_result()->fetch_assoc();

$errors = [];
$proposed = $_POST['code'] ?? $latest['code'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($proposed === '') {
        $errors[] = 'Code cannot be empty.';
    } elseif (mb_strlen($proposed) > 10000) {
        $errors[] = 'Code is too long (' . mb_strlen($proposed) . ' chars; max 10,000).';
    } elseif ($proposed === $latest['code']) {
        $errors[] = 'No changes were made.';
    }

    if (empty($errors)) {
        if ($is_owner) {
            // Direct insert as next version (TRANSACTION)
            $conn->begin_transaction();
            try {
                $next_version = (int)$latest['version_number'] + 1;
                $lines_changed = compute_lines_changed($latest['code'], $proposed);

                $stmt = $conn->prepare("
                    INSERT INTO versions
                      (repo_id, version_number, code, author_id, lines_changed)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->bind_param('iisii', $repo_id, $next_version, $proposed, $me, $lines_changed);
                $stmt->execute();

                audit_log($conn, $me, 'version_create', 'repositories', $repo_id,
                          "Owner direct-saved v{$next_version} ({$lines_changed} lines changed).");

                $conn->commit();
                flash('success', "Saved as version {$next_version}.");
                redirect('/repos/view.php?id=' . $repo_id);
            } catch (mysqli_sql_exception $e) {
                $conn->rollback();
                $errors[] = 'Save failed: ' . $e->getMessage();
            }
        } else {
            // Non-owner → create a pending change_request
            try {
                $stmt = $conn->prepare("
                    INSERT INTO change_requests (repo_id, proposed_code, requester_id)
                    VALUES (?, ?, ?)
                ");
                $stmt->bind_param('isi', $repo_id, $proposed, $me);
                $stmt->execute();
                $cr_id = $conn->insert_id;

                audit_log($conn, $me, 'change_request_filed', 'change_requests', $cr_id,
                          "Filed change request on repo #{$repo_id}.");

                flash('success', 'Change request submitted to the owner for review.');
                redirect('/repos/view.php?id=' . $repo_id);
            } catch (mysqli_sql_exception $e) {
                $errors[] = 'Could not submit change: ' . $e->getMessage();
            }
        }
    }
}

/**
 * Simple line-change estimator: count of lines that differ between
 * old and new. Good enough for the stats; Phase 4 may add a real diff.
 */
function compute_lines_changed($old, $new) {
    $a = explode("\n", $old);
    $b = explode("\n", $new);
    $max = max(count($a), count($b));
    $changed = 0;
    for ($i = 0; $i < $max; $i++) {
        $av = $a[$i] ?? null;
        $bv = $b[$i] ?? null;
        if ($av !== $bv) $changed++;
    }
    return $changed;
}

$page_title = ($is_owner ? 'Edit ' : 'Propose change to ') . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  <?= $is_owner ? 'Edit code' : 'Propose change' ?>
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<?php if (!$is_owner): ?>
  <div class="alert" style="background:#fff8e1;border-color:#ffd54f;color:#7c5c00">
    You are not the owner of this repository. Your changes will be sent to
    <strong>@<?= h($repo['owner_username']) ?></strong> as a change request.
  </div>
<?php endif; ?>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">
    <?php foreach ($errors as $e): ?><div><?= h($e) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="card">
  <form method="post" action="<?= BASE_URL ?>/repos/edit.php?id=<?= $repo_id ?>">
    <div class="form-group">
      <label for="code">
        Code (current version: v<?= (int)$latest['version_number'] ?>)
      </label>
      <textarea id="code" name="code" required
                maxlength="10000" style="min-height:380px"><?= h($proposed) ?></textarea>
      <div class="form-hint">Maximum 10,000 characters.</div>
    </div>
    <div class="form-actions">
      <button class="btn btn-primary" type="submit">
        <?= $is_owner ? 'Save as new version' : 'Submit change request' ?>
      </button>
      <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>