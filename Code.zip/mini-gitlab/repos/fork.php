<?php
/**
 * repos/fork.php — Fork a public repository.
 *
 * "Fork" here just means pinning a public repo to your dashboard.
 * No code is copied. It's a row in the forks table.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(400); die('Invalid repo.'); }

// Fetch repo and validate
$stmt = $conn->prepare("
    SELECT repo_id, name, visibility, owner_id, deleted_at
    FROM repositories WHERE repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || $repo['deleted_at']) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();

// Can't fork your own repo
if ((int)$repo['owner_id'] === (int)$me) {
    flash('error', "You can't fork your own repository.");
    redirect('/repos/view.php?id=' . $repo_id);
}

// Must be public (private can't be forked even by contributors per your spec)
if ($repo['visibility'] !== 'public') {
    flash('error', "Only public repositories can be forked.");
    redirect('/repos/view.php?id=' . $repo_id);
}

try {
    $stmt = $conn->prepare("INSERT INTO forks (repo_id, user_id) VALUES (?, ?)");
    $stmt->bind_param('ii', $repo_id, $me);
    $stmt->execute();
    audit_log($conn, $me, 'repo_fork', 'repositories', $repo_id, "Forked repo.");
    flash('success', "Forked '" . $repo['name'] . "' to your dashboard.");
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1062) {
        flash('error', "You've already forked this repository.");
    } else {
        flash('error', "Could not fork: " . $e->getMessage());
    }
}
redirect('/repos/view.php?id=' . $repo_id);