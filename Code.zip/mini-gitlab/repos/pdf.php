<?php
/**
 * repos/pdf.php — Export current version as PDF using FPDF.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Fetch repo + latest version
$stmt = $conn->prepare("
    SELECT r.*, u.username AS owner_username
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE r.repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || ($repo['deleted_at'] && !is_admin())) {
    http_response_code(404); die('Repo not found.');
}

$me = current_user_id();
$is_owner = $me && ((int)$repo['owner_id'] === (int)$me);
$is_contributor = false;
if ($me && !$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) { http_response_code(403); die('Private repository.'); }

// Fetch latest code
$stmt = $conn->prepare("
    SELECT code, version_number, created_at FROM versions
    WHERE repo_id = ? ORDER BY version_number DESC LIMIT 1
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$ver = $stmt->get_result()->fetch_assoc();
if (!$ver) { http_response_code(404); die('No versions found.'); }

require_once(__DIR__ . '/../assets/lib/fpdf.php');

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->SetMargins(15, 15, 15);
$pdf->SetAutoPageBreak(true, 15);
$pdf->AddPage();

// Title
$pdf->SetFont('Helvetica', 'B', 18);
$pdf->Cell(0, 10, $repo['name'], 0, 1);

// Metadata
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetTextColor(100, 100, 100);
$meta = "Version " . $ver['version_number'] . " - " . $repo['language']
      . " - " . date('M j, Y', strtotime($ver['created_at']))
      . " - Owner: @" . $repo['owner_username'];
$pdf->Cell(0, 6, $meta, 0, 1);
$pdf->Ln(4);

// Code block — FPDF uses Latin-1 internally so we sanitize
$pdf->SetFont('Courier', '', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFillColor(245, 245, 245);

// Convert UTF-8 to Latin-1 (replace unsupported chars with '?')
$code = mb_convert_encoding($ver['code'], 'ISO-8859-1', 'UTF-8');
$pdf->MultiCell(0, 5, $code, 0, 'L', true);

// Output as download
$filename = preg_replace('/[^A-Za-z0-9_\-]/', '_', $repo['name']) . '_v' . $ver['version_number'] . '.pdf';
$pdf->Output('D', $filename);
exit;