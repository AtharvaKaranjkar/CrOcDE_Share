<?php
/**
 * repos/react.php — Toggle like or dislike on a repository.
 *
 * Rules:
 *   - One reaction per user per repo (UNIQUE constraint enforces this)
 *   - Clicking the same type again → remove your reaction
 *   - Clicking the other type → switch reaction
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$repo_id = (int)($_GET['id']   ?? 0);
$type    = $_GET['type'] ?? '';

if ($repo_id <= 0 || !in_array($type, ['like', 'dislike'], true)) {
    http_response_code(400); die('Invalid request.');
}

// Verify the repo is viewable
$stmt = $conn->prepare("SELECT visibility, owner_id, deleted_at FROM repositories WHERE repo_id = ?");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || $repo['deleted_at']) {
    flash('error', 'Repo not found.'); redirect('/');
}

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);
$is_contributor = false;
if (!$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) {
    flash('error', "You can't react to a private repository you don't have access to.");
    redirect('/');
}

// Check existing reaction
$stmt = $conn->prepare("SELECT type FROM reactions WHERE repo_id = ? AND user_id = ?");
$stmt->bind_param('ii', $repo_id, $me);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();

if ($existing === null) {
    // No reaction yet → insert
    $stmt = $conn->prepare("INSERT INTO reactions (repo_id, user_id, type) VALUES (?, ?, ?)");
    $stmt->bind_param('iis', $repo_id, $me, $type);
    $stmt->execute();
    flash('success', "You {$type}d this repo.");

} elseif ($existing['type'] === $type) {
    // Same type → remove
    $stmt = $conn->prepare("DELETE FROM reactions WHERE repo_id = ? AND user_id = ?");
    $stmt->bind_param('ii', $repo_id, $me);
    $stmt->execute();
    flash('success', "Removed your {$type}.");

} else {
    // Switch
    $stmt = $conn->prepare("UPDATE reactions SET type = ? WHERE repo_id = ? AND user_id = ?");
    $stmt->bind_param('sii', $type, $repo_id, $me);
    $stmt->execute();
    flash('success', "Changed to {$type}.");
}

redirect('/repos/view.php?id=' . $repo_id);