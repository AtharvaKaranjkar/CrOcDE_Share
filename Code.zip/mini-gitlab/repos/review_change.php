<?php
/**
 * repos/review_change.php — Owner reviews a change request.
 *
 * Shows current code vs. proposed side-by-side.
 * Accept → calls sp_accept_change_request (creates version, updates request, notifies).
 * Reject → marks status='rejected', notifies requester.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$repo_id    = (int)($_GET['id']  ?? 0);
$request_id = (int)($_GET['req'] ?? 0);
if ($repo_id <= 0 || $request_id <= 0) { http_response_code(404); die('Not found.'); }

// Fetch repo
$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);

// Fetch the change request
$stmt = $conn->prepare("
    SELECT cr.*, u.username AS requester_name
    FROM change_requests cr
    JOIN users u ON u.user_id = cr.requester_id
    WHERE cr.request_id = ? AND cr.repo_id = ?
");
$stmt->bind_param('ii', $request_id, $repo_id);
$stmt->execute();
$cr = $stmt->get_result()->fetch_assoc();
if (!$cr) { http_response_code(404); die('Change request not found.'); }

// Access: owner can accept/reject; requester can view; admin can view.
$can_review = $is_owner || is_admin();
$can_view   = $can_review || ((int)$cr['requester_id'] === (int)$me);
if (!$can_view) { http_response_code(403); die('Access denied.'); }

// Fetch latest version code
$stmt = $conn->prepare("
    SELECT code, version_number FROM versions
    WHERE repo_id = ? ORDER BY version_number DESC LIMIT 1
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$latest = $stmt->get_result()->fetch_assoc();

// Handle accept/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $can_review) {
    block_if_suspended();
    $action = $_POST['action'] ?? '';

    if ($action === 'accept') {
        try {
            // Call stored procedure
            $stmt = $conn->prepare("CALL sp_accept_change_request(?, ?)");
            $stmt->bind_param('ii', $request_id, $me);
            $stmt->execute();
            flash('success', 'Change request accepted and saved as a new version.');
            redirect('/repos/view.php?id=' . $repo_id);
        } catch (mysqli_sql_exception $e) {
            flash('error', 'Could not accept: ' . $e->getMessage());
        }

    } elseif ($action === 'reject') {
        $stmt = $conn->prepare("
            UPDATE change_requests SET status = 'rejected', resolved_at = NOW()
            WHERE request_id = ?
        ");
        $stmt->bind_param('i', $request_id);
        $stmt->execute();

        audit_log($conn, $me, 'change_request_rejected', 'change_requests', $request_id,
                  "Rejected CR#{$request_id}.");

        // Notify requester
        $msg = "Your change request on repo #" . $repo_id . " was rejected.";
        $stmt2 = $conn->prepare("
            INSERT INTO notifications (user_id, type, message, link)
            VALUES (?, 'change_request_rejected', ?, ?)
        ");
        $link = "/repos/view.php?id={$repo_id}";
        $stmt2->bind_param('iss', $cr['requester_id'], $msg, $link);
        $stmt2->execute();

        flash('success', 'Change request rejected.');
        redirect('/repos/change_requests.php?id=' . $repo_id);
    }
}

$page_title = 'Review change · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Review change request
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<p class="text-muted">
  Proposed by
  <a href="<?= BASE_URL ?>/profile.php?user=<?= h($cr['requester_name']) ?>">@<?= h($cr['requester_name']) ?></a>
  on <?= h(date('M j, Y g:i A', strtotime($cr['created_at']))) ?>.
  Status: <strong><?= h($cr['status']) ?></strong>.
</p>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="card">
    <strong>Current version (v<?= (int)$latest['version_number'] ?>)</strong>
    <small class="text-muted"> · <?= mb_strlen($latest['code']) ?> chars</small>
    <pre class="code-block" style="margin-top:8px"><?= h($latest['code']) ?></pre>
  </div>
  <div class="card">
    <strong>Proposed change</strong>
    <small class="text-muted"> · <?= mb_strlen($cr['proposed_code']) ?> chars</small>
    <pre class="code-block" style="margin-top:8px"><?= h($cr['proposed_code']) ?></pre>
  </div>
</div>

<?php if ($can_review && $cr['status'] === 'pending'): ?>
<div class="card">
  <h2 class="card-title">Actions</h2>
  <div class="flex gap-2">
    <form method="post" action="<?= BASE_URL ?>/repos/review_change.php?id=<?= $repo_id ?>&req=<?= $request_id ?>">
      <input type="hidden" name="action" value="accept">
      <button class="btn btn-primary" type="submit"
              onclick="return confirm('Accept this change and save it as the next version?')">
        Accept change
      </button>
    </form>
    <form method="post" action="<?= BASE_URL ?>/repos/review_change.php?id=<?= $repo_id ?>&req=<?= $request_id ?>">
      <input type="hidden" name="action" value="reject">
      <button class="btn btn-danger" type="submit"
              onclick="return confirm('Reject this change request?')">
        Reject
      </button>
    </form>
  </div>
</div>
<?php endif; ?>

<div class="flex gap-2">
  <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/change_requests.php?id=<?= $repo_id ?>">
    ← Back to change requests
  </a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>