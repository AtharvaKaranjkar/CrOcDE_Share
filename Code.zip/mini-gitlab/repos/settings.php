<?php
/**
 * repos/settings.php — Owner/admin settings.
 *
 * Phase 3 additions:
 *   - Add contributor (by username)
 *   - Remove contributor
 *   - Transfer ownership
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ?");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
$is_owner = ((int)$repo['owner_id'] === (int)$me);
if (!$is_owner && !is_admin()) {
    http_response_code(403);
    die('Only the owner or an admin can change settings.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    block_if_suspended();
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle_visibility') {
        $new = ($repo['visibility'] === 'public') ? 'private' : 'public';
        $stmt = $conn->prepare("UPDATE repositories SET visibility = ? WHERE repo_id = ?");
        $stmt->bind_param('si', $new, $repo_id);
        $stmt->execute();
        audit_log($conn, $me, 'repo_visibility_changed', 'repositories', $repo_id,
                  "Visibility → {$new}.");
        flash('success', "Visibility set to {$new}.");
        redirect('/repos/settings.php?id=' . $repo_id);

    } elseif ($action === 'soft_delete') {
        $stmt = $conn->prepare("UPDATE repositories SET deleted_at = NOW() WHERE repo_id = ?");
        $stmt->bind_param('i', $repo_id);
        $stmt->execute();
        audit_log($conn, $me, 'repo_soft_delete', 'repositories', $repo_id, "Soft-deleted.");
        flash('success', "Repository deleted.");
        redirect(is_admin() ? '/admin/index.php' : '/dashboard.php');

    } elseif ($action === 'undelete' && is_admin()) {
        $stmt = $conn->prepare("UPDATE repositories SET deleted_at = NULL WHERE repo_id = ?");
        $stmt->bind_param('i', $repo_id);
        $stmt->execute();
        audit_log($conn, $me, 'repo_undelete', 'repositories', $repo_id, "Restored.");
        flash('success', "Repository restored.");
        redirect('/repos/settings.php?id=' . $repo_id);
    }
}

// Contributors list
$stmt = $conn->prepare("
    SELECT u.user_id, u.username, rc.added_at
    FROM repo_contributors rc
    JOIN users u ON u.user_id = rc.user_id
    WHERE rc.repo_id = ?
    ORDER BY rc.added_at ASC
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$contributors = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = 'Settings · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Settings
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<div class="card">
  <h2 class="card-title">Visibility</h2>
  <p>Current:
    <span class="badge <?= $repo['visibility'] === 'public' ? 'badge-public' : 'badge-private' ?>">
      <?= h($repo['visibility']) ?>
    </span>
  </p>
  <p class="text-muted">
    Making a repo private hides it from explore. Forks by non-contributors will
    no longer see it on their dashboard.
  </p>
  <form method="post" action="<?= BASE_URL ?>/repos/settings.php?id=<?= $repo_id ?>">
    <input type="hidden" name="action" value="toggle_visibility">
    <button class="btn btn-outline" type="submit">
      Switch to <?= $repo['visibility'] === 'public' ? 'private' : 'public' ?>
    </button>
  </form>
</div>

<div class="card">
  <h2 class="card-title">Contributors (<?= count($contributors) ?>)</h2>

  <form method="post" action="<?= BASE_URL ?>/repos/contributors.php?id=<?= $repo_id ?>"
        style="display:flex;gap:10px;align-items:flex-end;margin-bottom:16px">
    <input type="hidden" name="action" value="add">
    <div class="form-group" style="flex:1;margin-bottom:0">
      <label for="username">Add by username</label>
      <input id="username" name="username" type="text" maxlength="50" required
             placeholder="e.g. bob">
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-primary" type="submit">Add contributor</button>
    </div>
  </form>

  <?php if (empty($contributors)): ?>
    <p class="text-muted mb-0">No contributors yet.</p>
  <?php else: ?>
    <table class="table">
      <thead><tr><th>Username</th><th>Added</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($contributors as $c): ?>
          <tr>
            <td><a href="<?= BASE_URL ?>/profile.php?user=<?= h($c['username']) ?>">@<?= h($c['username']) ?></a></td>
            <td class="text-muted"><?= h(date('M j, Y', strtotime($c['added_at']))) ?></td>
            <td class="text-right">
              <form method="post" action="<?= BASE_URL ?>/repos/contributors.php?id=<?= $repo_id ?>"
                    style="display:inline"
                    onsubmit="return confirm('Remove @<?= h($c['username']) ?> as a contributor?');">
                <input type="hidden" name="action" value="remove">
                <input type="hidden" name="user_id" value="<?= (int)$c['user_id'] ?>">
                <button class="btn btn-outline btn-sm" type="submit">Remove</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<div class="card">
  <h2 class="card-title">Tags</h2>
  <p class="text-muted">
    Tag your repository so others can find it on the explore page filter.
  </p>
  <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/tags.php?id=<?= $repo_id ?>">
    Manage tags
  </a>
</div>

<?php if ($is_owner): ?>
<div class="card">
  <h2 class="card-title">Transfer ownership</h2>
  <p class="text-muted">
    The new owner must be an existing, non-admin, non-suspended user.
    You'll automatically become a contributor afterwards.
  </p>
  <form method="post" action="<?= BASE_URL ?>/repos/transfer.php?id=<?= $repo_id ?>"
        style="display:flex;gap:10px;align-items:flex-end"
        onsubmit="return confirm('Transfer ownership? This is reversible only if the new owner transfers back.');">
    <div class="form-group" style="flex:1;margin-bottom:0">
      <label for="new_owner">New owner's username</label>
      <input id="new_owner" name="new_owner" type="text" maxlength="50" required>
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-danger" type="submit">Transfer ownership</button>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="card">
  <h2 class="card-title" style="color:var(--error)">Danger zone</h2>
  <?php if ($repo['deleted_at'] === null): ?>
    <p>Soft-delete this repository. Admins can restore it later.</p>
    <form method="post" action="<?= BASE_URL ?>/repos/settings.php?id=<?= $repo_id ?>"
          onsubmit="return confirm('Delete this repository?');">
      <input type="hidden" name="action" value="soft_delete">
      <button class="btn btn-danger" type="submit">Delete repository</button>
    </form>
  <?php else: ?>
    <p>Deleted on <strong><?= h(date('M j, Y g:i A', strtotime($repo['deleted_at']))) ?></strong>.</p>
    <?php if (is_admin()): ?>
      <form method="post" action="<?= BASE_URL ?>/repos/settings.php?id=<?= $repo_id ?>">
        <input type="hidden" name="action" value="undelete">
        <button class="btn btn-outline" type="submit">Restore repository</button>
      </form>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>