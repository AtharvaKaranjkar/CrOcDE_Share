<?php
/**
 * repos/tags.php — Add or remove a tag on a repository (owner only).
 *
 * GET shows the tag management page.
 * POST: action=add (create-tag-if-missing, then attach)
 *       action=remove (detach a tag)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

$stmt = $conn->prepare("SELECT * FROM repositories WHERE repo_id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
if ((int)$repo['owner_id'] !== (int)$me && !is_admin()) {
    http_response_code(403);
    die('Only the owner or an admin can manage tags.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    block_if_suspended();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $tag_name = strtolower(trim($_POST['tag'] ?? ''));
        if (!preg_match('/^[a-z0-9\-]{1,50}$/', $tag_name)) {
            flash('error', 'Tag: 1–50 chars, lowercase letters/numbers/dash.');
        } else {
            // Create the tag if it doesn't exist, then attach
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT IGNORE INTO tags (name) VALUES (?)");
                $stmt->bind_param('s', $tag_name);
                $stmt->execute();

                $stmt = $conn->prepare("SELECT tag_id FROM tags WHERE name = ?");
                $stmt->bind_param('s', $tag_name);
                $stmt->execute();
                $tag_id = (int)$stmt->get_result()->fetch_assoc()['tag_id'];

                $stmt = $conn->prepare("INSERT IGNORE INTO repo_tags (repo_id, tag_id) VALUES (?, ?)");
                $stmt->bind_param('ii', $repo_id, $tag_id);
                $stmt->execute();

                $conn->commit();
                audit_log($conn, $me, 'tag_added', 'repositories', $repo_id,
                          "Added tag '{$tag_name}'.");
                flash('success', "Tag '{$tag_name}' added.");
            } catch (mysqli_sql_exception $e) {
                $conn->rollback();
                flash('error', 'Could not add: ' . $e->getMessage());
            }
        }

    } elseif ($action === 'remove') {
        $tag_id = (int)($_POST['tag_id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM repo_tags WHERE repo_id = ? AND tag_id = ?");
        $stmt->bind_param('ii', $repo_id, $tag_id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            audit_log($conn, $me, 'tag_removed', 'repositories', $repo_id,
                      "Removed tag_id={$tag_id}.");
            flash('success', 'Tag removed.');
        }
    }
    redirect('/repos/tags.php?id=' . $repo_id);
}

// Fetch current tags on this repo
$stmt = $conn->prepare("
    SELECT t.tag_id, t.name
    FROM repo_tags rt JOIN tags t ON t.tag_id = rt.tag_id
    WHERE rt.repo_id = ?
    ORDER BY t.name
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$current = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch all existing tags for suggestion
$all_tags = $conn->query("SELECT name FROM tags ORDER BY name")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Tags · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Tags
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<div class="card">
  <h2 class="card-title">Current tags (<?= count($current) ?>)</h2>

  <?php if (empty($current)): ?>
    <p class="text-muted">No tags yet.</p>
  <?php else: ?>
    <p>
      <?php foreach ($current as $t): ?>
        <span style="display:inline-flex;align-items:center;gap:6px;background:var(--crimson-light);color:var(--crimson-dark);padding:4px 10px;border-radius:99px;font-size:13px;margin-right:6px">
          <?= h($t['name']) ?>
          <form method="post" action="<?= BASE_URL ?>/repos/tags.php?id=<?= $repo_id ?>"
                style="display:inline;margin:0">
            <input type="hidden" name="action" value="remove">
            <input type="hidden" name="tag_id" value="<?= (int)$t['tag_id'] ?>">
            <button type="submit" style="background:none;border:none;color:var(--crimson-dark);cursor:pointer;font-size:14px;padding:0">×</button>
          </form>
        </span>
      <?php endforeach; ?>
    </p>
  <?php endif; ?>

  <form method="post" action="<?= BASE_URL ?>/repos/tags.php?id=<?= $repo_id ?>"
        style="display:flex;gap:10px;align-items:flex-end;margin-top:16px">
    <input type="hidden" name="action" value="add">
    <div class="form-group" style="flex:1;margin-bottom:0">
      <label for="tag">Add a tag</label>
      <input id="tag" name="tag" type="text" maxlength="50" required
             list="tag-suggestions" placeholder="e.g. algorithms">
      <datalist id="tag-suggestions">
        <?php foreach ($all_tags as $t): ?>
          <option value="<?= h($t['name']) ?>">
        <?php endforeach; ?>
      </datalist>
      <div class="form-hint">Lowercase letters, numbers, dashes; max 50 chars.</div>
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-primary" type="submit">Add tag</button>
    </div>
  </form>
</div>

<div class="flex gap-2">
  <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/settings.php?id=<?= $repo_id ?>">
    ← Back to settings
  </a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>