<?php
/**
 * repos/transfer.php — Transfer ownership to another user.
 *
 * Calls the sp_transfer_ownership stored procedure, which atomically:
 *   - Reassigns owner_id
 *   - Demotes old owner → contributor
 *   - Removes new owner from contributors (they're owner now)
 *   - Writes an audit_log row
 *   - Notifies the new owner
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
block_if_suspended();

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Only owner can transfer (the procedure also enforces this)
$stmt = $conn->prepare("SELECT owner_id, name FROM repositories WHERE repo_id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

$me = current_user_id();
if ((int)$repo['owner_id'] !== (int)$me) {
    http_response_code(403);
    die('Only the current owner can transfer ownership.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/repos/settings.php?id=' . $repo_id);
}

$new_owner_username = trim($_POST['new_owner'] ?? '');
if ($new_owner_username === '') {
    flash('error', "Enter the new owner's username.");
    redirect('/repos/settings.php?id=' . $repo_id);
}

// Look up the new owner's user_id
$stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
$stmt->bind_param('s', $new_owner_username);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) {
    flash('error', "No user named '{$new_owner_username}'.");
    redirect('/repos/settings.php?id=' . $repo_id);
}
$new_owner_id = (int)$row['user_id'];

// Call the stored procedure
try {
    $stmt = $conn->prepare("CALL sp_transfer_ownership(?, ?, ?)");
    $stmt->bind_param('iii', $repo_id, $me, $new_owner_id);
    $stmt->execute();
    flash('success', "Ownership transferred to @{$new_owner_username}. You are now a contributor.");
} catch (mysqli_sql_exception $e) {
    flash('error', "Transfer failed: " . $e->getMessage());
}

redirect('/repos/view.php?id=' . $repo_id);