<?php
/**
 * repos/unfork.php — Remove a fork pin from the user's dashboard.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
refresh_suspension_status($conn);
// Note: not block_if_suspended — unforking is a "stop following" action,
// allowed even when suspended.

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(400); die('Invalid repo.'); }

$me = current_user_id();
$stmt = $conn->prepare("DELETE FROM forks WHERE repo_id = ? AND user_id = ?");
$stmt->bind_param('ii', $repo_id, $me);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    audit_log($conn, $me, 'repo_unfork', 'repositories', $repo_id, "Unforked repo.");
    flash('success', "Removed fork from your dashboard.");
} else {
    flash('error', "You weren't forking this repository.");
}
redirect('/repos/view.php?id=' . $repo_id);