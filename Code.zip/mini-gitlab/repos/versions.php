<?php
/**
 * repos/versions.php — Version history.
 *
 * Visibility rules:
 *   - Owner / admin: all versions
 *   - Contributor: latest + one previous
 *   - Viewer (public repo): latest only
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Fetch repo
$stmt = $conn->prepare("
    SELECT r.*, u.username AS owner_username
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE r.repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

if ($repo['deleted_at'] !== null && !is_admin()) {
    http_response_code(404); die('Repo not found.');
}

$me = current_user_id();
$is_owner = $me && ((int)$repo['owner_id'] === (int)$me);
$is_contributor = false;
if ($me && !$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) { http_response_code(403); die('This repository is private.'); }

// Determine how many versions to show
$limit = 999999; // effectively unlimited for owner/admin
if ($is_contributor && !is_admin() && !$is_owner) {
    $limit = 2; // latest + one previous
} elseif (!$is_owner && !$is_contributor && !is_admin()) {
    $limit = 1; // latest only
}

$stmt = $conn->prepare("
    SELECT v.version_id, v.version_number, v.lines_changed, v.created_at,
           u.username AS author_name,
           CHAR_LENGTH(v.code) AS char_count
    FROM versions v
    JOIN users u ON u.user_id = v.author_id
    WHERE v.repo_id = ?
    ORDER BY v.version_number DESC
    LIMIT ?
");
$stmt->bind_param('ii', $repo_id, $limit);
$stmt->execute();
$versions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = 'Versions · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Version history
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<?php if ($limit === 1): ?>
  <div class="alert" style="background:#fff8e1;border-color:#ffd54f;color:#7c5c00">
    You can only see the latest version. To see more, become a contributor.
  </div>
<?php elseif ($limit === 2): ?>
  <div class="alert" style="background:#fff8e1;border-color:#ffd54f;color:#7c5c00">
    Contributors see the latest version + one previous. The owner sees full history.
  </div>
<?php endif; ?>

<div class="card">
  <h2 class="card-title">Versions (showing <?= count($versions) ?>)</h2>

  <?php if (empty($versions)): ?>
    <p class="text-muted mb-0">No versions yet.</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Version</th>
          <th>Author</th>
          <th>Lines changed</th>
          <th>Chars</th>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($versions as $v): ?>
          <tr>
            <td>
              <strong>v<?= (int)$v['version_number'] ?></strong>
              <?php if ($v === $versions[0]): ?>
                <span class="badge" style="background:var(--success-bg);color:var(--success)">latest</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?= BASE_URL ?>/profile.php?user=<?= h($v['author_name']) ?>">
                @<?= h($v['author_name']) ?>
              </a>
            </td>
            <td><?= (int)$v['lines_changed'] ?></td>
            <td><?= (int)$v['char_count'] ?></td>
            <td class="text-muted"><?= h(date('M j, Y g:i A', strtotime($v['created_at']))) ?></td>
            <td class="text-right">
              <a class="btn btn-outline btn-sm"
                 href="<?= BASE_URL ?>/repos/view_version.php?id=<?= $repo_id ?>&v=<?= (int)$v['version_number'] ?>">
                View
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php if (count($versions) >= 2): ?>
<div class="card">
  <h2 class="card-title">Compare versions</h2>
  <form method="get" action="<?= BASE_URL ?>/repos/compare.php" style="display:flex;gap:10px;align-items:flex-end">
    <input type="hidden" name="id" value="<?= $repo_id ?>">
    <div class="form-group" style="margin-bottom:0">
      <label for="from">From version</label>
      <select id="from" name="from" required>
        <?php foreach ($versions as $v): ?>
          <option value="<?= (int)$v['version_number'] ?>">v<?= (int)$v['version_number'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group" style="margin-bottom:0">
      <label for="to">To version</label>
      <select id="to" name="to" required>
        <?php foreach ($versions as $v): ?>
          <option value="<?= (int)$v['version_number'] ?>"
                  <?= $v === $versions[0] ? 'selected' : '' ?>>
            v<?= (int)$v['version_number'] ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-actions" style="margin:0">
      <button class="btn btn-primary" type="submit">Compare</button>
    </div>
  </form>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>