<?php
/**
 * repos/view.php — Repository page.
 *
 * Phase 5 additions:
 *   - Reaction bar (like / dislike with counts)
 *   - Tag pills under header
 *   - Threaded comments (recursive CTE via v_comment_threads)
 *   - Inline reply forms
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
if ($repo_id <= 0) { http_response_code(404); die('Repo not found.'); }

// Repo + owner
$stmt = $conn->prepare("
    SELECT r.repo_id, r.name, r.language, r.visibility, r.owner_id,
           r.view_count, r.created_at, r.updated_at, r.deleted_at,
           u.username AS owner_username
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE r.repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo) { http_response_code(404); die('Repo not found.'); }

if ($repo['deleted_at'] !== null && !is_admin()) {
    http_response_code(404); die('Repo not found.');
}

$me = current_user_id();
$is_owner       = $me && ((int)$repo['owner_id'] === (int)$me);

$is_contributor = false;
if ($me && !$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$has_forked = false;
if ($me && !$is_owner && !$is_contributor) {
    $s3 = $conn->prepare("SELECT 1 FROM forks WHERE repo_id=? AND user_id=?");
    $s3->bind_param('ii', $repo_id, $me);
    $s3->execute();
    $has_forked = (bool)$s3->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) { http_response_code(403); die('This repository is private.'); }

// Latest version
$stmt = $conn->prepare("
    SELECT version_number, code, created_at,
           (SELECT username FROM users WHERE user_id = v.author_id) AS author_name
    FROM versions v WHERE repo_id = ? ORDER BY version_number DESC LIMIT 1
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$latest = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("SELECT COUNT(*) AS n FROM versions WHERE repo_id = ?");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$total_versions = (int)$stmt->get_result()->fetch_assoc()['n'];

// Contributors
$stmt = $conn->prepare("
    SELECT u.user_id, u.username
    FROM repo_contributors rc
    JOIN users u ON u.user_id = rc.user_id
    WHERE rc.repo_id = ?
    ORDER BY rc.added_at ASC
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$contributors = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Tags
$stmt = $conn->prepare("
    SELECT t.tag_id, t.name
    FROM repo_tags rt JOIN tags t ON t.tag_id = rt.tag_id
    WHERE rt.repo_id = ?
    ORDER BY t.name
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$tags = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Reaction counts + my reaction
$stmt = $conn->prepare("
    SELECT
        SUM(CASE WHEN type='like'    THEN 1 ELSE 0 END) AS likes,
        SUM(CASE WHEN type='dislike' THEN 1 ELSE 0 END) AS dislikes
    FROM reactions WHERE repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$rx = $stmt->get_result()->fetch_assoc();
$likes_n    = (int)($rx['likes']    ?? 0);
$dislikes_n = (int)($rx['dislikes'] ?? 0);

$my_reaction = null;
if ($me) {
    $stmt = $conn->prepare("SELECT type FROM reactions WHERE repo_id = ? AND user_id = ?");
    $stmt->bind_param('ii', $repo_id, $me);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $my_reaction = $row['type'] ?? null;
}

// Comments via the recursive view
$stmt = $conn->prepare("
    SELECT comment_id, parent_comment_id, body, deleted_at, created_at, depth, username, user_id
    FROM v_comment_threads
    WHERE repo_id = ?
    ORDER BY sort_path
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$comments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Increment view counter
if ($me && !$is_owner && !$is_contributor && !is_admin()) {
    if (empty($_SESSION['_viewed'][$repo_id])) {
        $conn->query("UPDATE repositories SET view_count = view_count + 1 WHERE repo_id = {$repo_id}");
        $_SESSION['_viewed'][$repo_id] = 1;
    }
}

$page_title = $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="flex-between mb-2">
  <div>
    <h1 class="mt-0 mb-0">
      <?= h($repo['name']) ?>
      <span class="badge <?= $repo['visibility'] === 'public' ? 'badge-public' : 'badge-private' ?>">
        <?= h($repo['visibility']) ?>
      </span>
      <span class="badge badge-crimson"><?= h($repo['language']) ?></span>
      <?php if ($repo['deleted_at']): ?>
        <span class="badge" style="background:#fdecea;color:#c62828">soft-deleted</span>
      <?php endif; ?>

      <?php
      if ($is_owner || is_admin()) {
          $stmt2 = $conn->prepare("SELECT COUNT(*) AS n FROM change_requests WHERE repo_id = ? AND status = 'pending'");
          $stmt2->bind_param('i', $repo_id);
          $stmt2->execute();
          $pending = (int)$stmt2->get_result()->fetch_assoc()['n'];
          if ($pending > 0) {
              echo '<a href="' . BASE_URL . '/repos/change_requests.php?id=' . $repo_id . '">';
              echo '<span class="badge" style="background:#fff8e1;color:#7c5c00">';
              echo $pending . ' pending request' . ($pending === 1 ? '' : 's');
              echo '</span></a>';
          }
      }
      ?>
    </h1>
    <p class="text-muted mt-1 mb-0">
      Owned by <a href="<?= BASE_URL ?>/profile.php?user=<?= h($repo['owner_username']) ?>">
        @<?= h($repo['owner_username']) ?></a> ·
      Created <?= h(date('M j, Y', strtotime($repo['created_at']))) ?> ·
      Updated <?= h(date('M j, Y', strtotime($repo['updated_at']))) ?> ·
      <a href="<?= BASE_URL ?>/repos/versions.php?id=<?= $repo_id ?>">
        <?= $total_versions ?> version<?= $total_versions === 1 ? '' : 's' ?>
      </a> ·
      <?= (int)$repo['view_count'] ?> view<?= (int)$repo['view_count'] === 1 ? '' : 's' ?>
    </p>
  </div>
  <div class="flex gap-2">
    <?php if (is_logged_in() && !is_admin() && !is_suspended()): ?>
      <?php if ($is_owner || $is_contributor): ?>
        <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>/repos/edit.php?id=<?= $repo_id ?>">
          <?= $is_owner ? 'Edit code' : 'Propose change' ?>
        </a>
      <?php elseif ($repo['visibility'] === 'public'): ?>
        <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>/repos/edit.php?id=<?= $repo_id ?>">
          Propose change
        </a>
        <?php if ($has_forked): ?>
          <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/repos/unfork.php?id=<?= $repo_id ?>">
            Unfork
          </a>
        <?php else: ?>
          <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/repos/fork.php?id=<?= $repo_id ?>">
            Fork
          </a>
        <?php endif; ?>
      <?php endif; ?>
    <?php endif; ?>

    <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/repos/pdf.php?id=<?= $repo_id ?>">PDF</a>

    <?php if ($is_owner || is_admin()): ?>
      <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/repos/settings.php?id=<?= $repo_id ?>">
        Settings
      </a>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($contributors) || !empty($tags)): ?>
<div class="card" style="padding:14px 24px">
  <?php if (!empty($contributors)): ?>
    <strong style="font-size:13px;color:var(--grey-700)">Contributors:</strong>
    <?php foreach ($contributors as $i => $c): ?>
      <?php if ($i > 0) echo ' · '; ?>
      <a href="<?= BASE_URL ?>/profile.php?user=<?= h($c['username']) ?>">@<?= h($c['username']) ?></a>
    <?php endforeach; ?>
    <?php if (!empty($tags)) echo '<br>'; ?>
  <?php endif; ?>
  <?php if (!empty($tags)): ?>
    <strong style="font-size:13px;color:var(--grey-700)">Tags:</strong>
    <?php foreach ($tags as $t): ?>
      <a href="<?= BASE_URL ?>/?tag=<?= h($t['name']) ?>"
         style="display:inline-block;background:var(--crimson-light);color:var(--crimson-dark);padding:2px 10px;border-radius:99px;font-size:12px;text-decoration:none;margin-right:4px">
        <?= h($t['name']) ?>
      </a>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Reaction bar -->
<div class="card" style="padding:14px 24px">
  <div class="flex gap-2" style="align-items:center">
    <?php if (is_logged_in() && !is_suspended()): ?>
      <a class="btn btn-sm <?= $my_reaction === 'like' ? 'btn-primary' : 'btn-outline' ?>"
         href="<?= BASE_URL ?>/repos/react.php?id=<?= $repo_id ?>&type=like">
        👍 <?= $likes_n ?>
      </a>
      <a class="btn btn-sm <?= $my_reaction === 'dislike' ? 'btn-primary' : 'btn-outline' ?>"
         href="<?= BASE_URL ?>/repos/react.php?id=<?= $repo_id ?>&type=dislike">
        👎 <?= $dislikes_n ?>
      </a>
      <?php if ($my_reaction): ?>
        <span class="text-muted" style="font-size:13px">
          (You <?= $my_reaction ?>d this. Click the same button again to remove.)
        </span>
      <?php endif; ?>
    <?php else: ?>
      <span class="btn btn-outline btn-sm" style="cursor:default">👍 <?= $likes_n ?></span>
      <span class="btn btn-outline btn-sm" style="cursor:default">👎 <?= $dislikes_n ?></span>
      <?php if (!is_logged_in()): ?>
        <span class="text-muted" style="font-size:13px">
          <a href="<?= BASE_URL ?>/auth/login.php">Log in</a> to react.
        </span>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<!-- Code block -->
<div class="card">
  <div class="flex-between mb-2">
    <strong>
      Version <?= (int)$latest['version_number'] ?>
      <span class="text-muted" style="font-weight:400">
        · by <a href="<?= BASE_URL ?>/profile.php?user=<?= h($latest['author_name']) ?>">@<?= h($latest['author_name']) ?></a>
        · <?= h(date('M j, Y g:i A', strtotime($latest['created_at']))) ?>
      </span>
    </strong>
    <span class="text-muted" style="font-size:12px">
      <?= mb_strlen($latest['code']) ?> chars
    </span>
  </div>
  <pre class="code-block"><?= h($latest['code']) ?></pre>
</div>

<!-- Comments section -->
<div class="card" id="comments">
  <h2 class="card-title">Comments (<?= count(array_filter($comments, fn($c) => !$c['deleted_at'])) ?>)</h2>

  <?php if (is_logged_in() && !is_suspended()): ?>
    <form method="post" action="<?= BASE_URL ?>/comments/post.php" style="margin-bottom:20px">
      <input type="hidden" name="repo_id" value="<?= $repo_id ?>">
      <div class="form-group">
        <label for="body">Add a comment</label>
        <textarea id="body" name="body" required maxlength="2000"
                  style="min-height:80px;font-family:inherit" placeholder="Share your thoughts..."></textarea>
        <div class="form-hint">Max 2000 chars. Comments can't be edited, only deleted.</div>
      </div>
      <button class="btn btn-primary" type="submit">Post comment</button>
    </form>
  <?php elseif (!is_logged_in()): ?>
    <p class="text-muted"><a href="<?= BASE_URL ?>/auth/login.php">Log in</a> to comment.</p>
  <?php endif; ?>

  <?php if (empty($comments)): ?>
    <p class="text-muted mb-0">No comments yet. Be the first.</p>
  <?php else: ?>
    <?php foreach ($comments as $c):
        $indent = min((int)$c['depth'], 6) * 28;
    ?>
      <div id="comment-<?= (int)$c['comment_id'] ?>"
           style="margin-left:<?= $indent ?>px;padding:10px 0;border-top:1px solid var(--grey-200)">
        <div class="flex-between">
          <div>
            <strong>
              <a href="<?= BASE_URL ?>/profile.php?user=<?= h($c['username']) ?>">
                @<?= h($c['username']) ?>
              </a>
            </strong>
            <span class="text-muted" style="font-size:12px">
              · <?= h(date('M j, Y g:i A', strtotime($c['created_at']))) ?>
            </span>
          </div>
          <?php if (!$c['deleted_at'] && (is_logged_in()) && ((int)$c['user_id'] === (int)$me || is_admin())): ?>
            <form method="post" action="<?= BASE_URL ?>/comments/delete.php" style="margin:0"
                  onsubmit="return confirm('Delete this comment?');">
              <input type="hidden" name="comment_id" value="<?= (int)$c['comment_id'] ?>">
              <button type="submit" class="btn btn-outline btn-sm">Delete</button>
            </form>
          <?php endif; ?>
        </div>
        <div style="margin-top:6px">
          <?php if ($c['deleted_at']): ?>
            <em class="text-muted">[deleted]</em>
          <?php else: ?>
            <?= nl2br(h($c['body'])) ?>
          <?php endif; ?>
        </div>
        <?php if (!$c['deleted_at'] && is_logged_in() && !is_suspended() && (int)$c['depth'] < 6): ?>
          <details style="margin-top:6px">
            <summary style="cursor:pointer;font-size:13px;color:var(--crimson)">Reply</summary>
            <form method="post" action="<?= BASE_URL ?>/comments/post.php" style="margin-top:8px">
              <input type="hidden" name="repo_id" value="<?= $repo_id ?>">
              <input type="hidden" name="parent_comment_id" value="<?= (int)$c['comment_id'] ?>">
              <textarea name="body" required maxlength="2000"
                        style="min-height:60px;font-family:inherit" placeholder="Reply..."></textarea>
              <button class="btn btn-primary btn-sm mt-1" type="submit">Reply</button>
            </form>
          </details>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>