<?php
/**
 * repos/view_version.php — View a specific version.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
if (is_logged_in()) refresh_suspension_status($conn);

$repo_id = (int)($_GET['id'] ?? 0);
$v_num   = (int)($_GET['v']  ?? 0);
if ($repo_id <= 0 || $v_num <= 0) { http_response_code(404); die('Not found.'); }

// Repo check
$stmt = $conn->prepare("
    SELECT r.*, u.username AS owner_username
    FROM repositories r
    JOIN users u ON u.user_id = r.owner_id
    WHERE r.repo_id = ?
");
$stmt->bind_param('i', $repo_id);
$stmt->execute();
$repo = $stmt->get_result()->fetch_assoc();
if (!$repo || ($repo['deleted_at'] && !is_admin())) {
    http_response_code(404); die('Repo not found.');
}

$me = current_user_id();
$is_owner = $me && ((int)$repo['owner_id'] === (int)$me);
$is_contributor = false;
if ($me && !$is_owner) {
    $s2 = $conn->prepare("SELECT 1 FROM repo_contributors WHERE repo_id=? AND user_id=?");
    $s2->bind_param('ii', $repo_id, $me);
    $s2->execute();
    $is_contributor = (bool)$s2->get_result()->fetch_row();
}

$can_view = ($repo['visibility'] === 'public') || $is_owner || $is_contributor || is_admin();
if (!$can_view) { http_response_code(403); die('Private repository.'); }

// Fetch the version
$stmt = $conn->prepare("
    SELECT v.*, u.username AS author_name
    FROM versions v
    JOIN users u ON u.user_id = v.author_id
    WHERE v.repo_id = ? AND v.version_number = ?
");
$stmt->bind_param('ii', $repo_id, $v_num);
$stmt->execute();
$ver = $stmt->get_result()->fetch_assoc();
if (!$ver) { http_response_code(404); die('Version not found.'); }

// Visibility rule check: if viewer/contributor can only see certain versions,
// enforce it (same logic as versions.php)
$can_see_all = $is_owner || is_admin();
if (!$can_see_all) {
    $stmt = $conn->prepare("SELECT MAX(version_number) AS latest FROM versions WHERE repo_id=?");
    $stmt->bind_param('i', $repo_id);
    $stmt->execute();
    $latest = (int)$stmt->get_result()->fetch_assoc()['latest'];

    if ($is_contributor) {
        // can see latest and one previous
        if ($v_num < ($latest - 1)) {
            http_response_code(403);
            die('You can only view the latest version and one previous.');
        }
    } else {
        // viewer: only latest
        if ($v_num !== $latest) {
            http_response_code(403);
            die('You can only view the latest version.');
        }
    }
}

$page_title = 'v' . $v_num . ' · ' . $repo['name'];
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="mt-0">
  Version <?= (int)$ver['version_number'] ?>
  <span class="text-muted" style="font-weight:400">·
    <a href="<?= BASE_URL ?>/repos/view.php?id=<?= $repo_id ?>"><?= h($repo['name']) ?></a>
  </span>
</h1>

<p class="text-muted">
  by <a href="<?= BASE_URL ?>/profile.php?user=<?= h($ver['author_name']) ?>">@<?= h($ver['author_name']) ?></a> ·
  <?= h(date('M j, Y g:i A', strtotime($ver['created_at']))) ?> ·
  <?= (int)$ver['lines_changed'] ?> lines changed ·
  <?= mb_strlen($ver['code']) ?> chars
</p>

<div class="card">
  <pre class="code-block"><?= h($ver['code']) ?></pre>
</div>

<div class="flex gap-2">
  <a class="btn btn-outline" href="<?= BASE_URL ?>/repos/versions.php?id=<?= $repo_id ?>">
    ← Back to version history
  </a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>