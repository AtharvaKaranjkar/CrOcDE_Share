-- =============================================================
--  MINI-GITLAB  |  PHASE 0  |  01_schema.sql
--  Creates the database and all 13 tables with constraints,
--  foreign keys, and indexes.
--
--  How to run:
--    1. Open phpMyAdmin (http://localhost/phpmyadmin)
--    2. Click the SQL tab on the left sidebar (NOT inside a DB)
--    3. Paste this entire file and click "Go"
--
--  Safe to re-run: drops existing tables in the right order
--  before recreating them. The database itself is preserved.
-- =============================================================

CREATE DATABASE IF NOT EXISTS mini_gitlab
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE mini_gitlab;

-- -------------------------------------------------------------
-- Drop tables in reverse-dependency order so re-runs are clean
-- -------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS follows;
DROP TABLE IF EXISTS repo_tags;
DROP TABLE IF EXISTS tags;
DROP TABLE IF EXISTS forks;
DROP TABLE IF EXISTS reactions;
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS change_requests;
DROP TABLE IF EXISTS repo_contributors;
DROP TABLE IF EXISTS versions;
DROP TABLE IF EXISTS repositories;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;


-- =============================================================
-- 1. USERS
--    The pre-seeded admin (user_id=1) is protected by:
--      - CHECK constraint:  admins can't be suspended
--      - Trigger (added in 06_triggers.sql) to block deletion
-- =============================================================
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  username       VARCHAR(50)  NOT NULL UNIQUE,
  email          VARCHAR(100) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('admin','user') NOT NULL DEFAULT 'user',
  is_suspended   TINYINT(1)   NOT NULL DEFAULT 0,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT chk_admin_not_suspended
    CHECK ( NOT (role = 'admin' AND is_suspended = 1) ),

  INDEX idx_users_role       (role),
  INDEX idx_users_suspended  (is_suspended)
) ENGINE=InnoDB;


-- =============================================================
-- 2. REPOSITORIES
-- =============================================================
CREATE TABLE repositories (
  repo_id      INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100) NOT NULL,
  language     ENUM('C++','C','Python','Java','JavaScript',
                    'Go','Rust','SQL','Other') NOT NULL,
  visibility   ENUM('public','private') NOT NULL DEFAULT 'public',
  owner_id     INT NOT NULL,
  view_count   INT NOT NULL DEFAULT 0,
  deleted_at   DATETIME NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_repo_owner
    FOREIGN KEY (owner_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  INDEX idx_repo_owner       (owner_id),
  INDEX idx_repo_language    (language),
  INDEX idx_repo_visibility  (visibility),
  INDEX idx_repo_deleted     (deleted_at),
  FULLTEXT INDEX ft_repo_name (name)
) ENGINE=InnoDB;


-- =============================================================
-- 3. VERSIONS
--    Every accepted code change becomes a new row.
--    UNIQUE(repo_id, version_number) keeps numbering tidy.
-- =============================================================
CREATE TABLE versions (
  version_id      INT AUTO_INCREMENT PRIMARY KEY,
  repo_id         INT NOT NULL,
  version_number  INT NOT NULL,
  code            TEXT NOT NULL,
  author_id       INT NOT NULL,
  lines_changed   INT NOT NULL DEFAULT 0,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_version_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_version_author
    FOREIGN KEY (author_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  CONSTRAINT chk_version_code_length
    CHECK ( CHAR_LENGTH(code) <= 10000 ),

  UNIQUE KEY uk_repo_version (repo_id, version_number),
  INDEX idx_version_author   (author_id),
  INDEX idx_version_created  (created_at)
) ENGINE=InnoDB;


-- =============================================================
-- 4. REPO_CONTRIBUTORS  (many-to-many: users ↔ repositories)
-- =============================================================
CREATE TABLE repo_contributors (
  repo_id   INT NOT NULL,
  user_id   INT NOT NULL,
  added_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (repo_id, user_id),

  CONSTRAINT fk_contrib_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_contrib_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


-- =============================================================
-- 5. CHANGE_REQUESTS
--    A non-owner's proposed edit lives here until the owner
--    accepts/rejects it (see sp_accept_change_request later).
-- =============================================================
CREATE TABLE change_requests (
  request_id      INT AUTO_INCREMENT PRIMARY KEY,
  repo_id         INT NOT NULL,
  proposed_code   TEXT NOT NULL,
  requester_id    INT NOT NULL,
  status          ENUM('pending','accepted','rejected') NOT NULL
                    DEFAULT 'pending',
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at     DATETIME NULL,

  CONSTRAINT fk_cr_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_cr_requester
    FOREIGN KEY (requester_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  CONSTRAINT chk_cr_code_length
    CHECK ( CHAR_LENGTH(proposed_code) <= 10000 ),

  INDEX idx_cr_repo_status (repo_id, status),
  INDEX idx_cr_requester   (requester_id)
) ENGINE=InnoDB;


-- =============================================================
-- 6. COMMENTS  (self-referencing for replies)
--    Soft-delete via deleted_at so threads stay readable.
-- =============================================================
CREATE TABLE comments (
  comment_id         INT AUTO_INCREMENT PRIMARY KEY,
  repo_id            INT NOT NULL,
  user_id            INT NOT NULL,
  parent_comment_id  INT NULL,
  body               TEXT NOT NULL,
  deleted_at         DATETIME NULL,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_comment_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_comment_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_comment_parent
    FOREIGN KEY (parent_comment_id) REFERENCES comments(comment_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  INDEX idx_comment_repo    (repo_id),
  INDEX idx_comment_parent  (parent_comment_id)
) ENGINE=InnoDB;


-- =============================================================
-- 7. REACTIONS  (one per user per repo, like or dislike)
-- =============================================================
CREATE TABLE reactions (
  reaction_id  INT AUTO_INCREMENT PRIMARY KEY,
  repo_id      INT NOT NULL,
  user_id      INT NOT NULL,
  type         ENUM('like','dislike') NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_reaction_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_reaction_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  UNIQUE KEY uk_reaction_user_repo (repo_id, user_id),
  INDEX idx_reaction_type (type)
) ENGINE=InnoDB;


-- =============================================================
-- 8. FORKS  (viewer pins a public repo to their dashboard)
-- =============================================================
CREATE TABLE forks (
  fork_id    INT AUTO_INCREMENT PRIMARY KEY,
  repo_id    INT NOT NULL,
  user_id    INT NOT NULL,
  forked_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_fork_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_fork_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  UNIQUE KEY uk_fork_user_repo (repo_id, user_id)
) ENGINE=InnoDB;


-- =============================================================
-- 9. TAGS  +  10. REPO_TAGS  (many-to-many tag system)
-- =============================================================
CREATE TABLE tags (
  tag_id  INT AUTO_INCREMENT PRIMARY KEY,
  name    VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE repo_tags (
  repo_id  INT NOT NULL,
  tag_id   INT NOT NULL,

  PRIMARY KEY (repo_id, tag_id),

  CONSTRAINT fk_rt_repo
    FOREIGN KEY (repo_id) REFERENCES repositories(repo_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_rt_tag
    FOREIGN KEY (tag_id) REFERENCES tags(tag_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


-- =============================================================
-- 11. FOLLOWS  (self-referencing M:N on users)
-- =============================================================
CREATE TABLE follows (
  follower_id  INT NOT NULL,
  followee_id  INT NOT NULL,
  followed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (follower_id, followee_id),

  -- NOTE: ON UPDATE CASCADE is intentionally omitted here.
  -- MariaDB forbids CHECK constraints on columns whose FKs use
  -- ON UPDATE CASCADE (the cascade could change the value without
  -- re-validating the CHECK). user_id is AUTO_INCREMENT and never
  -- updated in this project, so omitting CASCADE is safe.
  CONSTRAINT fk_follow_follower
    FOREIGN KEY (follower_id) REFERENCES users(user_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_follow_followee
    FOREIGN KEY (followee_id) REFERENCES users(user_id)
    ON DELETE CASCADE,

  CONSTRAINT chk_no_self_follow
    CHECK (follower_id <> followee_id)
) ENGINE=InnoDB;


-- =============================================================
-- 12. NOTIFICATIONS
-- =============================================================
CREATE TABLE notifications (
  notif_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  type        ENUM('change_request_filed',
                   'change_request_accepted',
                   'change_request_rejected',
                   'new_follower',
                   'contributor_added',
                   'ownership_transferred',
                   'comment_reply',
                   'account_suspended',
                   'account_unsuspended') NOT NULL,
  message     VARCHAR(500) NOT NULL,
  link        VARCHAR(500) NULL,
  is_read     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_notif_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,

  INDEX idx_notif_user_read (user_id, is_read),
  INDEX idx_notif_created   (created_at)
) ENGINE=InnoDB;


-- =============================================================
-- 13. AUDIT_LOG
--    actor_id is SET NULL on actor deletion so history survives.
-- =============================================================
CREATE TABLE audit_log (
  log_id       INT AUTO_INCREMENT PRIMARY KEY,
  actor_id     INT NULL,
  action       VARCHAR(100) NOT NULL,
  target_type  VARCHAR(50)  NULL,
  target_id    INT          NULL,
  details      TEXT         NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_audit_actor
    FOREIGN KEY (actor_id) REFERENCES users(user_id)
    ON DELETE SET NULL ON UPDATE CASCADE,

  INDEX idx_audit_actor   (actor_id),
  INDEX idx_audit_action  (action),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;


-- =============================================================
-- DONE. Run 02_seed.sql next to insert the admin user + default tags.
-- =============================================================
