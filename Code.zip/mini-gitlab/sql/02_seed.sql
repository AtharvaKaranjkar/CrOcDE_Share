-- =============================================================
--  MINI-GITLAB  |  PHASE 0  |  02_seed.sql
--  Inserts the permanent admin user and a small default tag set.
--
--  How to run:
--    1. Open phpMyAdmin
--    2. Click the mini_gitlab database on the sidebar
--    3. Click the SQL tab
--    4. Paste this file and click "Go"
--
--  Admin credentials:
--    username: admin
--    password: admin@123
--
--  The password_hash below is a real bcrypt $2b$10$ hash
--  generated for "admin@123" and verified to work with
--  PHP's password_verify().
-- =============================================================

USE mini_gitlab;

-- -------------------------------------------------------------
-- 1. The permanent admin (user_id = 1, locked in by triggers later)
-- -------------------------------------------------------------
INSERT INTO users (user_id, username, email, password_hash, role, is_suspended)
VALUES (
  1,
  'admin',
  'admin@minigitlab.local',
  '$2b$10$2LcRL4kCrg4FVoOcz8gjU.hOcgXW/9xpUiEslp8s5AltYC2r0Vq/i',
  'admin',
  0
);

-- -------------------------------------------------------------
-- 2. Default tag set so the explore filter has something on first
--    boot. Users can create more tags as needed.
-- -------------------------------------------------------------
INSERT INTO tags (name) VALUES
  ('algorithms'),
  ('data-structures'),
  ('web'),
  ('machine-learning'),
  ('beginner'),
  ('advanced'),
  ('leetcode'),
  ('project');

-- -------------------------------------------------------------
-- 3. One initial audit_log entry recording the seed itself
-- -------------------------------------------------------------
INSERT INTO audit_log (actor_id, action, target_type, target_id, details)
VALUES (1, 'database_seeded', 'system', NULL,
        'Initial seed: admin user + default tags inserted.');

-- =============================================================
-- DONE. The database is ready. You can now log in as admin.
-- =============================================================
