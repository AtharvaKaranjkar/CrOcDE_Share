-- =============================================================
--  PHASE 3  |  03_procedures.sql
--  Stored procedure: transfer ownership.
--  Atomically reassigns owner and demotes the old owner to contributor.
-- =============================================================

USE mini_gitlab;

DROP PROCEDURE IF EXISTS sp_transfer_ownership;

DELIMITER //

CREATE PROCEDURE sp_transfer_ownership(
    IN p_repo_id    INT,
    IN p_actor_id   INT,
    IN p_new_owner  INT
)
BEGIN
    DECLARE v_current_owner INT;
    DECLARE v_repo_exists   INT;

    -- Custom error for cleaner error messages
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- 1. Repo must exist and not be soft-deleted
    SELECT owner_id INTO v_current_owner
      FROM repositories
      WHERE repo_id = p_repo_id AND deleted_at IS NULL
      FOR UPDATE;

    IF v_current_owner IS NULL THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Repository not found or deleted.';
    END IF;

    -- 2. Actor must be current owner (admin override handled in PHP)
    IF v_current_owner <> p_actor_id THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Only the current owner can transfer ownership.';
    END IF;

    -- 3. New owner must exist, not be admin, not be suspended
    SELECT COUNT(*) INTO v_repo_exists
      FROM users
      WHERE user_id = p_new_owner
        AND role = 'user'
        AND is_suspended = 0;

    IF v_repo_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'New owner must be an active (non-admin, non-suspended) user.';
    END IF;

    -- 4. New owner cannot be the same as current owner
    IF v_current_owner = p_new_owner THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'That user is already the owner.';
    END IF;

    -- 5. Change the owner
    UPDATE repositories SET owner_id = p_new_owner WHERE repo_id = p_repo_id;

    -- 6. Demote old owner → contributor (INSERT IGNORE because they
    --    might already be in there from before)
    INSERT IGNORE INTO repo_contributors (repo_id, user_id)
        VALUES (p_repo_id, v_current_owner);

    -- 7. Remove new owner from contributors (they're owner now)
    DELETE FROM repo_contributors
        WHERE repo_id = p_repo_id AND user_id = p_new_owner;

    -- 8. Audit log
    INSERT INTO audit_log (actor_id, action, target_type, target_id, details)
      VALUES (p_actor_id, 'repo_ownership_transferred', 'repositories', p_repo_id,
              CONCAT('Owner ', v_current_owner, ' → ', p_new_owner));

    -- 9. Notify the new owner
    INSERT INTO notifications (user_id, type, message, link)
      VALUES (p_new_owner, 'ownership_transferred',
              CONCAT('You are now the owner of repository #', p_repo_id),
              CONCAT('/repos/view.php?id=', p_repo_id));

    COMMIT;
END //

DELIMITER ;

SELECT 'sp_transfer_ownership created.' AS status;