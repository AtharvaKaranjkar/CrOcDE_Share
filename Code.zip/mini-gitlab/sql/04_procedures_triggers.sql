-- =============================================================
--  PHASE 4  |  Stored procedure + trigger additions
--  sp_accept_change_request — atomically creates a version,
--    updates the request status, and sends a notification.
--  tr_version_insert — auto-sets lines_changed if not provided.
-- =============================================================

USE mini_gitlab;

-- -------------------------------------------------------------
-- Stored procedure: accept a change request
-- -------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_accept_change_request;

DELIMITER //

CREATE PROCEDURE sp_accept_change_request(
    IN p_request_id  INT,
    IN p_actor_id    INT
)
BEGIN
    DECLARE v_repo_id       INT;
    DECLARE v_requester_id  INT;
    DECLARE v_proposed_code TEXT;
    DECLARE v_current_owner INT;
    DECLARE v_next_version  INT;
    DECLARE v_lines_changed INT;
    DECLARE v_latest_code   TEXT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- 1. Fetch and lock the change request
    SELECT repo_id, requester_id, proposed_code, status
      INTO v_repo_id, v_requester_id, v_proposed_code, @status
      FROM change_requests
      WHERE request_id = p_request_id
      FOR UPDATE;

    IF v_repo_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Change request not found.';
    END IF;

    IF @status <> 'pending' THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Change request is not pending.';
    END IF;

    -- 2. Verify actor is the owner
    SELECT owner_id INTO v_current_owner
      FROM repositories WHERE repo_id = v_repo_id AND deleted_at IS NULL;

    IF v_current_owner IS NULL THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Repository not found or deleted.';
    END IF;

    IF v_current_owner <> p_actor_id THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Only the owner can accept change requests.';
    END IF;

    -- 3. Compute next version number
    SELECT COALESCE(MAX(version_number), 0) + 1 INTO v_next_version
      FROM versions WHERE repo_id = v_repo_id;

    -- 4. Get latest code to compute lines changed
    SELECT code INTO v_latest_code
      FROM versions
      WHERE repo_id = v_repo_id
      ORDER BY version_number DESC
      LIMIT 1;

    -- Simple line diff: count differing lines
    SET v_lines_changed = (
        LENGTH(v_proposed_code) - LENGTH(REPLACE(v_proposed_code, '\n', ''))
      ) + 1;
    -- This is a placeholder; the trigger will refine it if needed.

    -- 5. Insert the new version (author = requester)
    INSERT INTO versions (repo_id, version_number, code, author_id, lines_changed)
      VALUES (v_repo_id, v_next_version, v_proposed_code, v_requester_id, v_lines_changed);

    -- 6. Mark request as accepted
    UPDATE change_requests
      SET status = 'accepted', resolved_at = NOW()
      WHERE request_id = p_request_id;

    -- 7. Audit log
    INSERT INTO audit_log (actor_id, action, target_type, target_id, details)
      VALUES (p_actor_id, 'change_request_accepted', 'change_requests', p_request_id,
              CONCAT('Accepted CR#', p_request_id, ' → v', v_next_version));

    -- 8. Notify the requester
    INSERT INTO notifications (user_id, type, message, link)
      VALUES (v_requester_id, 'change_request_accepted',
              CONCAT('Your change request on repo #', v_repo_id, ' was accepted as v', v_next_version),
              CONCAT('/repos/view.php?id=', v_repo_id));

    COMMIT;
END //

DELIMITER ;

-- -------------------------------------------------------------
-- Trigger: auto-compute lines_changed if it's 0
-- (The PHP code in edit.php already computes it, but the
--  stored procedure above sets a placeholder. This trigger
--  refines it if needed.)
-- -------------------------------------------------------------
DROP TRIGGER IF EXISTS tr_version_insert;

DELIMITER //

CREATE TRIGGER tr_version_insert
BEFORE INSERT ON versions
FOR EACH ROW
BEGIN
    DECLARE v_prev_code TEXT;

    -- If lines_changed was set to 0 or NULL, recompute it
    IF NEW.lines_changed IS NULL OR NEW.lines_changed = 0 THEN
        -- Fetch the previous version's code
        SELECT code INTO v_prev_code
          FROM versions
          WHERE repo_id = NEW.repo_id
          ORDER BY version_number DESC
          LIMIT 1;

        IF v_prev_code IS NOT NULL THEN
            -- Simple diff: count lines that differ
            SET NEW.lines_changed = ABS(
                (LENGTH(NEW.code) - LENGTH(REPLACE(NEW.code, '\n', ''))) -
                (LENGTH(v_prev_code) - LENGTH(REPLACE(v_prev_code, '\n', '')))
            ) + 1;
        ELSE
            -- First version: count lines in new code
            SET NEW.lines_changed = (LENGTH(NEW.code) - LENGTH(REPLACE(NEW.code, '\n', ''))) + 1;
        END IF;
    END IF;
END //

DELIMITER ;

SELECT 'sp_accept_change_request and tr_version_insert created.' AS status;