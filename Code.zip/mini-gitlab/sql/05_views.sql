-- =============================================================
--  PHASE 5  |  05_views.sql
--  Recursive view: comment threads with depth info.
--  Used by the comments section to render nested replies.
-- =============================================================

USE mini_gitlab;

DROP VIEW IF EXISTS v_comment_threads;

CREATE VIEW v_comment_threads AS
WITH RECURSIVE thread AS (
    -- Anchor: top-level comments
    SELECT
        c.comment_id,
        c.repo_id,
        c.user_id,
        c.parent_comment_id,
        c.body,
        c.deleted_at,
        c.created_at,
        0 AS depth,
        CAST(LPAD(c.comment_id, 8, '0') AS CHAR(200)) AS sort_path
    FROM comments c
    WHERE c.parent_comment_id IS NULL

    UNION ALL

    -- Recursive: replies to anything already in the result
    SELECT
        c.comment_id,
        c.repo_id,
        c.user_id,
        c.parent_comment_id,
        c.body,
        c.deleted_at,
        c.created_at,
        t.depth + 1 AS depth,
        CONCAT(t.sort_path, '/', LPAD(c.comment_id, 8, '0')) AS sort_path
    FROM comments c
    JOIN thread t ON c.parent_comment_id = t.comment_id
)
SELECT
    t.comment_id,
    t.repo_id,
    t.user_id,
    t.parent_comment_id,
    t.body,
    t.deleted_at,
    t.created_at,
    t.depth,
    t.sort_path,
    u.username
FROM thread t
JOIN users u ON u.user_id = t.user_id;

SELECT 'v_comment_threads created.' AS status;