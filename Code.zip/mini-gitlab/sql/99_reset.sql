-- =============================================================
--  MINI-GITLAB  |  PHASE 0  |  99_reset.sql
--  Wipes the entire database EXCEPT the admin user and the
--  default tag set. Resets all AUTO_INCREMENT counters so the
--  next user inserted becomes user_id=2, the next repo becomes
--  repo_id=1, etc.
--
--  Use this before a fresh demo.
--
--  How to run:
--    1. Open phpMyAdmin
--    2. Click the mini_gitlab database on the sidebar
--    3. Click the SQL tab
--    4. Paste this file and click "Go"
-- =============================================================

USE mini_gitlab;

-- -------------------------------------------------------------
-- Disable FK checks so TRUNCATE works on FK-referenced tables.
-- -------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;

-- Order doesn't strictly matter with FK_CHECKS=0, but listing
-- child tables first is good practice.
TRUNCATE TABLE audit_log;
TRUNCATE TABLE notifications;
TRUNCATE TABLE follows;
TRUNCATE TABLE repo_tags;
TRUNCATE TABLE forks;
TRUNCATE TABLE reactions;
TRUNCATE TABLE comments;
TRUNCATE TABLE change_requests;
TRUNCATE TABLE repo_contributors;
TRUNCATE TABLE versions;
TRUNCATE TABLE repositories;

-- Users: delete everyone EXCEPT the admin row
DELETE FROM users WHERE role <> 'admin';

-- Tags: wipe and re-seed so tag_ids start clean from 1
TRUNCATE TABLE tags;

SET FOREIGN_KEY_CHECKS = 1;

-- -------------------------------------------------------------
-- Reset AUTO_INCREMENT counters
-- -------------------------------------------------------------
-- users: admin occupies user_id=1, so the next new user starts at 2.
-- We can't TRUNCATE users (admin row must survive), and DELETE alone
-- doesn't move AUTO_INCREMENT — hence the explicit ALTER below.
ALTER TABLE users              AUTO_INCREMENT = 2;
ALTER TABLE repositories       AUTO_INCREMENT = 1;
ALTER TABLE versions           AUTO_INCREMENT = 1;
ALTER TABLE change_requests    AUTO_INCREMENT = 1;
ALTER TABLE comments           AUTO_INCREMENT = 1;
ALTER TABLE reactions          AUTO_INCREMENT = 1;
ALTER TABLE forks              AUTO_INCREMENT = 1;
ALTER TABLE tags               AUTO_INCREMENT = 1;
ALTER TABLE notifications      AUTO_INCREMENT = 1;
ALTER TABLE audit_log          AUTO_INCREMENT = 1;

-- -------------------------------------------------------------
-- Re-seed default tags
-- -------------------------------------------------------------
INSERT INTO tags (name) VALUES
  ('algorithms'),
  ('data-structures'),
  ('web'),
  ('machine-learning'),
  ('beginner'),
  ('advanced'),
  ('leetcode'),
  ('project');

-- -------------------------------------------------------------
-- Log that a reset happened
-- -------------------------------------------------------------
INSERT INTO audit_log (actor_id, action, target_type, target_id, details)
VALUES (1, 'database_reset', 'system', NULL,
        'Full reset: all non-admin data wiped, AUTO_INCREMENT reset, default tags re-seeded.');

-- =============================================================
-- DONE. Database is back to a fresh post-seed state.
-- Admin login (username: admin / password: admin@123) still works.
-- =============================================================
